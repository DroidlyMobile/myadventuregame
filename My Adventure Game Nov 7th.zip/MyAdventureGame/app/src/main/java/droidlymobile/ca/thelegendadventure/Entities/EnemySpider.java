package droidlymobile.ca.thelegendadventure.Entities;

import android.graphics.Canvas;
import droidlymobile.ca.thelegendadventure.GameView;

public class EnemySpider extends EntityInfo{

    public EnemySpider(GameView gameView){
        this.gameView = gameView;
    }

    public void update(){

    }

    public void draw(Canvas canvas){

    }
}