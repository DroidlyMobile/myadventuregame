package droidlymobile.ca.thelegendadventure.utils;

import droidlymobile.ca.thelegendadventure.Entities.EntityInfo;
import droidlymobile.ca.thelegendadventure.GameView;
public class CollisionChecker extends EntityInfo {
    public int checkPlayerLeftSide = 0;
    public int checkPlayerRightSide = 0;
    public int setPlayerLeftX;
    public int setPlayerRightX;
    public int checkPlayerTopSide;
    public int checkPlayerBottomSide;
    public int setPlayerTopY;
    public int setPlayerBottomY;
    public CollisionChecker(GameView gameView){
        this.gameView = gameView;
    }

    public void checkTileCollision(EntityInfo entity,final String entityDirection){
        //Check Right & Left
        checkPlayerLeftSide = (int) (entity.posX + entity.rectF.left);
        checkPlayerRightSide = (int) (entity.posX + entity.rectF.left + entity.rectF.right);
        setPlayerLeftX = checkPlayerLeftSide/gameView.defaultTilesize;
        setPlayerRightX = checkPlayerRightSide/gameView.defaultTilesize;
        //Check Up & Down
        checkPlayerTopSide = (int) (entity.posY + entity.rectF.top);
        checkPlayerBottomSide = (int) (entity.posY + entity.rectF.top + entity.rectF.bottom);
        setPlayerTopY = checkPlayerTopSide/gameView.defaultTilesize;
        setPlayerBottomY = checkPlayerBottomSide/gameView.defaultTilesize;//To round the current Y value we can -1 so that when the player is walking left or right they don't collide
        //When we go left or right we want to check the top tile and bottom tile position so that the player cannot walk through the tile halfway

        switch (entityDirection){
            case "left":
                setPlayerLeftX = (checkPlayerLeftSide - entity.speed)/gameView.defaultTilesize;
                setPlayerTopY = (checkPlayerTopSide+entity.speed)/gameView.defaultTilesize;
                setPlayerBottomY = (checkPlayerBottomSide-entity.speed)/gameView.defaultTilesize;
                checkTile1 = gameView.tileManager.worldTileNum[setPlayerLeftX][setPlayerTopY];
                checkTile2 = gameView.tileManager.worldTileNum[setPlayerLeftX][setPlayerBottomY];
                if (gameView.tileManager.tileInfo[checkTile1].tileCollision || gameView.tileManager.tileInfo[checkTile2].tileCollision){
                    entity.collision = true;
                }
                break;
            case "right":
                setPlayerRightX = (checkPlayerRightSide + entity.speed)/gameView.defaultTilesize;
                setPlayerBottomY = (checkPlayerBottomSide-entity.speed)/gameView.defaultTilesize;
                setPlayerTopY = (checkPlayerTopSide+entity.speed)/gameView.defaultTilesize;
                checkTile1 = gameView.tileManager.worldTileNum[setPlayerRightX][setPlayerTopY];
                checkTile2 = gameView.tileManager.worldTileNum[setPlayerRightX][setPlayerBottomY];
                if (gameView.tileManager.tileInfo[checkTile1].tileCollision || gameView.tileManager.tileInfo[checkTile2].tileCollision){
                    entity.collision = true;
                }
                break;
            case "up":
                setPlayerTopY = (checkPlayerTopSide - entity.speed)/gameView.defaultTilesize;
                setPlayerRightX = (checkPlayerRightSide - entity.speed)/gameView.defaultTilesize;
                setPlayerLeftX = (checkPlayerLeftSide + entity.speed)/gameView.defaultTilesize;
                checkTile1 = gameView.tileManager.worldTileNum[setPlayerLeftX][setPlayerTopY];
                checkTile2 = gameView.tileManager.worldTileNum[setPlayerRightX][setPlayerTopY];
                if (gameView.tileManager.tileInfo[checkTile1].tileCollision || gameView.tileManager.tileInfo[checkTile2].tileCollision){
                    entity.collision = true;
                }
                break;
            case "down":
                setPlayerBottomY = (checkPlayerBottomSide + entity.speed)/gameView.defaultTilesize;
                setPlayerRightX = (checkPlayerRightSide - entity.speed)/gameView.defaultTilesize;
                setPlayerLeftX = (checkPlayerLeftSide + entity.speed)/gameView.defaultTilesize;
                checkTile1 = gameView.tileManager.worldTileNum[setPlayerLeftX][setPlayerBottomY];
                checkTile2 = gameView.tileManager.worldTileNum[setPlayerRightX][setPlayerBottomY];
                if (gameView.tileManager.tileInfo[checkTile1].tileCollision || gameView.tileManager.tileInfo[checkTile2].tileCollision){
                    entity.collision = true;
                }
                break;
        }
    }
}
