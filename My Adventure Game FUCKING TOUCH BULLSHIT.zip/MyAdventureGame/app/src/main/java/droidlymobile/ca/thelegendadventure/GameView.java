package droidlymobile.ca.thelegendadventure;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import androidx.annotation.NonNull;

import droidlymobile.ca.thelegendadventure.Entities.Player;
import droidlymobile.ca.thelegendadventure.utils.CollisionChecker;
import droidlymobile.ca.thelegendadventure.utils.ControllerButtons;
import droidlymobile.ca.thelegendadventure.utils.DpadButtons;
import droidlymobile.ca.thelegendadventure.utils.Joystick;

public class GameView extends SurfaceView implements SurfaceHolder.Callback {

    SurfaceHolder surfaceHolder;
    public GameLoop2 gameLoop;
    public Paint textpaint = new Paint();
    public boolean buttontouched = false;
    public Player player;
    public boolean checkbuttonpressed = false;
    public boolean buttonright,buttonleft,buttonup,buttondown,buttonattack = false;
    public CollisionChecker collisionChecker;
    public int maxColumns,maxRows,defaultTilesize;
    public TileManager tileManager;
    public String checkbutton = "none";
    public String checkbutton2 = "none";
    public int pointerid,pointerindex = 0;
    public double actuator = 0;
    public boolean leftbutton = false;
    public boolean abutton = false;
    public Joystick joystick,joystick2;
    public int joystickPointerId,joystickPointerId2 = 0;
    public int dpadpointerid,buttonapointerid = 0;
    public ControllerButtons buttonLeft,buttonRight,buttonDown,buttonUp,buttonA;
    public int buttonWidth,buttonHeight = 0;

    public GameView(Context context){
        super(context);
        surfaceHolder = getHolder();
        surfaceHolder.addCallback(this);
        gameLoop = new GameLoop2(this,surfaceHolder);
        textpaint.setColor(Color.WHITE);
        textpaint.setTextSize(50);
        defaultTilesize = 160;
        player = new Player(this);
        collisionChecker = new CollisionChecker(this);
        maxColumns = 25;
        maxRows = 25;
        tileManager = new TileManager(this);
        buttonWidth = getDisplayHeight()/6;
        buttonHeight = getDisplayHeight()/6;
        buttonLeft = new ControllerButtons(this,0,buttonHeight*4);
        buttonRight = new ControllerButtons(this,buttonWidth*2,buttonHeight*4);
        buttonDown = new ControllerButtons(this,buttonWidth,buttonHeight*5);
    }

    public void update(){
        player.update();
    }
    public void draw(Canvas canvas){
        super.draw(canvas);
        tileManager.draw(canvas);
        tileManager.drawAllAnimatedTiles(canvas);
        canvas.drawText(String.valueOf(gameLoop.getAverageFPS()),
                getDisplayWidth()-320,
                textpaint.getTextSize() * 2, textpaint);

        canvas.drawText(String.valueOf(dpadpointerid) + " "
                        + String.valueOf(buttonapointerid) + " "
                        + checkbutton + " " + checkbutton2,
                getDisplayWidth()-1000,
                textpaint.getTextSize() * 3, textpaint);
        player.draw(canvas);
        buttonLeft.draw(canvas);
        buttonRight.draw(canvas);
        buttonDown.draw(canvas);
    }


    @Override
    public boolean onTouchEvent(MotionEvent event) {

        int pointIndex = event.getActionIndex();
        int pointID = event.getPointerId(pointIndex);
        dpadpointerid = pointID;

        switch (event.getActionMasked()){
            case 0:
            case 5:
                if (event.getX(event.getActionIndex()) > 1250){
                    if (!player.entityAttacking) {
                        checkbuttonpressed = true;
                        player.entityAttacking = true;
                        player.entityDown = false;
                        player.entityUp = false;
                        player.entityRight = false;
                        player.entityLeft = false;
                        player.entityAnimCounter = 0;
                        player.entityAnimNum = 1;
                    }
                }
            /*case 2: //check finger move*/
                if (buttonLeft.getXY((int) event.getX(event.getActionIndex()), (int) event.getY(event.getActionIndex()))){
                    if (!player.entityAttacking && !player.entityRight && !player.entityDown && !player.entityUp){
                        checkbuttonpressed = true;
                        player.entityLeft = true;
                        checkbutton = "left";
                    }
                }else if (buttonRight.getXY((int) event.getX(event.getActionIndex()), (int) event.getY(event.getActionIndex()))){
                    if (!player.entityAttacking && !player.entityLeft && !player.entityDown && !player.entityUp){
                        checkbuttonpressed = true;
                        player.entityRight = true;
                        checkbutton = "right";
                    }
                }else if (buttonDown.getXY((int) event.getX(event.getActionIndex()), (int) event.getY(event.getActionIndex()))){
                    if (!player.entityAttacking && !player.entityLeft && !player.entityRight && !player.entityUp){
                        checkbuttonpressed = true;
                        player.entityDown = true;
                        checkbutton = "down";
                    }
                }




                /*else {
                    if (!(event.getX(event.getActionIndex()) > 1250)) {
                        checkbuttonpressed = false;
                        player.entityLeft = false;
                        player.entityRight = false;
                        checkbutton = "none";
                    }
                }*/


                return true;

            case 1:
            case 6:
                if (buttonLeft.getXY((int) event.getX(event.getActionIndex()), (int) event.getY(event.getActionIndex()))){
                    if (!player.entityRight && !player.entityDown) {
                        checkbuttonpressed = false;
                        player.entityLeft = false;
                        checkbutton = "none";
                    }
                }else if (buttonRight.getXY((int) event.getX(event.getActionIndex()), (int) event.getY(event.getActionIndex()))){
                    if (!player.entityLeft && !player.entityDown) {
                        checkbuttonpressed = false;
                        player.entityRight = false;
                        checkbutton = "none";
                    }
                }else if (buttonDown.getXY((int) event.getX(event.getActionIndex()), (int) event.getY(event.getActionIndex()))){
                    if (!player.entityLeft && !player.entityRight) {
                        checkbuttonpressed = false;
                        player.entityDown = false;
                        checkbutton = "none";
                    }
                }

                return true;
        }
        return super.onTouchEvent(event);
    }

    @Override
    public boolean performClick() {
        int x = (int) this.getX();
        int y = (int) this.getY();
        System.out.println("CLICK BUTTON");
        return super.performClick();
    }

    /*@Override
    public boolean onTouchEvent(MotionEvent event) {

        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN:
                dpadpointerid = event.getPointerId(event.getActionIndex());
                buttonapointerid = event.getPointerId(event.getActionIndex());

                if (dpadButtons.isPressed(
                        event.getX(), (double) event.getY())) {
                    // Joystick is pressed in this event -> setIsPressed(true) and store pointer id
                    dpadpointerid = event.getPointerId(event.getActionIndex());
                    dpadButtons.setIsPressed(true);
                    if (dpadpointerid == event.getPointerId(event.getActionIndex())) {
                        if (!player.entityAttacking){
                            checkbuttonpressed = true;
                            player.entityLeft = true;
                            checkbutton = "left";
                        }
                    }
                }else if (dpadButtons2.isPressed(
                        event.getX(), (double) event.getY())) {
                    // Joystick is pressed in this event -> setIsPressed(true) and store pointer id
                    dpadpointerid = event.getPointerId(event.getActionIndex());
                    dpadButtons2.setIsPressed(true);
                    if (dpadpointerid == event.getPointerId(event.getActionIndex())) {
                        if (!player.entityAttacking) {
                            checkbuttonpressed = true;
                            player.entityUp = true;
                            checkbutton = "up";
                        }
                    }
                }
                if (attackbuttons.isPressed(event.getX(buttonapointerid),event.getY(buttonapointerid))){
                    attackbuttons.setIsPressed(true);
                    if (!player.entityAttacking) {
                        checkbuttonpressed = true;
                        player.entityAttacking = true;
                        player.entityDown = false;
                        player.entityUp = false;
                        player.entityRight = false;
                        player.entityLeft = false;
                        player.entityAnimCounter = 0;
                        player.entityAnimNum = 1;
                        attackbuttons.setIsPressed(false);

                    }
                }

                return true;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
                if (!dpadButtons.getIsPressed()) {
                    if (!player.entityAttacking) {
                        checkbuttonpressed = false;
                        player.entityLeft = false;
                    }
                    checkbutton = "none";
                }
                if (!dpadButtons2.getIsPressed()) {
                    if (!player.entityAttacking) {
                        checkbuttonpressed = false;
                        player.entityUp = false;
                    }
                    checkbutton = "none";
                }
                return true;
        }
        return super.onTouchEvent(event);
    }*/

    /*
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getActionMasked()){
            case MotionEvent.ACTION_DOWN:
                case MotionEvent.ACTION_POINTER_DOWN:
                    //UP BUTTON
                    if (event.getX()>0 &&
                            event.getX()<250
                            && event.getY()>0
                            && event.getY()<getDisplayWidth()){

                        if (event.getPointerCount() == 1) {
                                checkbutton = "up";
                            } else if (event.getPointerCount() == 2) {
                                if (event.getX(1) > 500 && event.getX(1) < getDisplayWidth()
                                        && event.getY(1) > 0
                                        && event.getY(1) < getDisplayHeight()) {
                                    checkbutton = "attackup";
                                }
                            }
                    }
                    //ATTACK BUTTON
                    if (event.getX() > 500 && event.getX() < getDisplayWidth()
                            && event.getY() > 0
                            && event.getY() < getDisplayHeight()) {
                        if (event.getPointerCount() == 1) {
                            checkbutton = "attackup";
                        } else if (event.getPointerCount() == 2) {
                            if (event.getX(1)>0 &&
                                    event.getX(1)<250
                                    && event.getY(1)>0
                                    && event.getY(1)<getDisplayWidth()){
                                checkbutton = "attackup";

                            }
                        }
                    }
                    pointerindex = (event.getAction() & MotionEvent.ACTION_POINTER_INDEX_MASK) >> MotionEvent.ACTION_POINTER_INDEX_SHIFT;

                    return true;
                    case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_POINTER_UP:
                    pointerindex = (event.getAction() & MotionEvent.ACTION_POINTER_INDEX_MASK) >> MotionEvent.ACTION_POINTER_INDEX_SHIFT;

                    if (pointerindex == 0){
                        if (checkbutton.equals("attackup")) {
                            checkbutton = "up";
                        }else {
                            checkbutton = "none";
                        }
                    }else if (pointerindex == 1 && checkbutton.equals("attackup")) {
                        checkbutton = "up";
                    }
                    break;

        }
        return true;
    }*/

    /*@Override
    public boolean onTouchEvent(MotionEvent event) {
        int getPointer = event.getActionIndex();
        int getPointerID = event.getPointerId(getPointer);
        pointerid = getPointerID;
        switch (event.getActionMasked()){
            case MotionEvent.ACTION_DOWN:
                if (event.getPointerCount()==1)
                if (event.getX(getPointerID)>0 && event.getX(getPointerID)<250){
                    //BUTTON LEFT
                    checkbutton = "button left";
                    if (!player.entityAttacking){
                        checkbuttonpressed = true;
                        player.entityLeft = true;
                        checkbutton = "left";
                    }
                }
            case MotionEvent.ACTION_POINTER_DOWN:
                if (event.getX(getPointerID)>0 && event.getX(getPointerID)<250){
                    //BUTTON LEFT
                    checkbutton = "button left";
                    if (!player.entityAttacking){
                        checkbuttonpressed = true;
                        player.entityLeft = true;
                        checkbutton = "left";
                    }
                }
                if (event.getX(getPointerID)>500){
                    //BUTTON A
                    if (checkbutton2.equals("")) {
                        checkbutton2 = "button a";

                    }
                    if (!player.entityAttacking) {
                        checkbuttonpressed = true;
                        player.entityAttacking = true;
                        player.entityDown = false;
                        player.entityUp = false;
                        player.entityRight = false;
                        player.entityLeft = false;
                        player.entityAnimCounter = 0;
                        player.entityAnimNum = 1;
                    }
                }
                case MotionEvent.ACTION_MOVE:
                    try {
                        if (!(event.getX(getPointer) > 0
                                && event.getX(getPointer) < 250)) {
                            //BUTTON LEFT
                            if (!player.entityAttacking) {
                                checkbuttonpressed = false;
                                player.entityLeft = false;
                            }
                            checkbutton = "none";
                        }else {
                            if (!player.entityAttacking){
                                checkbuttonpressed = true;
                                player.entityLeft = true;
                                checkbutton = "left";
                            }
                        }
                    }catch (Exception e){

                    }

                break;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
                try {


                if (event.getX(getPointerID)>0 && event.getX(getPointerID)<250){
                    //BUTTON LEFT
                    if (!player.entityAttacking) {
                        checkbuttonpressed = false;
                        player.entityLeft = false;
                    }
                    checkbutton = "none";
                }
                }catch (Exception e){

                }
                break;
        }
        return true;
        *//*return super.onTouchEvent(event);*//*
    }*/

    @Override
    public void surfaceCreated(@NonNull SurfaceHolder holder) {
        if (gameLoop.getState().equals(Thread.State.TERMINATED)){
            surfaceHolder = getHolder();
            surfaceHolder.addCallback(this);
            gameLoop = new GameLoop2(this,surfaceHolder);
        }
        gameLoop.startLoop();
    }

    @Override
    public void surfaceChanged(@NonNull SurfaceHolder holder, int format, int width, int height) {

    }

    @Override
    public void surfaceDestroyed(@NonNull SurfaceHolder holder) {

    }

    public int getDisplayWidth(){
        return getContext().getResources().getDisplayMetrics().widthPixels;
    }
    public int getDisplayHeight(){
        return getContext().getResources().getDisplayMetrics().heightPixels;
    }
}
