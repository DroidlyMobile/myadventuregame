package droidlymobile.ca.thelegendadventure.Entities;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;

import droidlymobile.ca.thelegendadventure.GameView;
import droidlymobile.ca.thelegendadventure.R;

public class Player extends EntityInfo{

    public Player(GameView gameView){
        this.gameView = gameView;
        initialize();
    }
    public void initialize(){
        entityWidth = 160;
        entityHeight = 160;
        rectF.left = 0;
        rectF.right = entityWidth;
        rectF.top = 0;
        rectF.bottom = entityHeight;
        hitboxpaint.setColor(Color.GREEN);
        screenPosX = gameView.getDisplayWidth()/2 - entityWidth/2;
        screenPosY = gameView.getDisplayHeight()/2 - entityHeight/2;
        initializeSpriteSheet();
        defaultEntityImg = entitySprites[0];
        entityAnimMaxCount = 16;
        speed = 6;
    }
    public void update(){
        updateEntityAnimations();
        updateEntityPosXY();
    }
    public void draw(Canvas canvas){
        canvas.drawRect(screenPosX,screenPosY,
                screenPosX + entityWidth,
                screenPosY + entityHeight,
                hitboxpaint);
        canvas.drawBitmap(defaultEntityImg,screenPosX,screenPosY,null);
    }

    private void updateEntityPosXY() {
        collision = false;
        gameView.collisionChecker.checkTestCollision(this,entityDirection);
            switch (entityDirection) {
                case "right":
                    if (!collision) {
                        screenPosX += speed;
                    }
                    break;
                case "left":
                    if (!collision) {
                        screenPosX -= speed;
                    }
                    break;
                case "down":
                    if (!collision) {
                        screenPosY += speed;
                    }
                    break;
                case "up":
                    if (!collision) {
                        screenPosY -= speed;
                    }
                    break;

        }
    }

    public void updateEntityAnimations() {
        if (gameView.checkbuttonpressed == false){
            entityDirection = "buttonreleased";
        }
        if (gameView.checkbuttonpressed) {
            entityAnimCounter++;
            if (entityAnimCounter > entityAnimMaxCount) {
                if (entityAnimNum == 1) {
                    entityAnimNum = 2;
                } else if (entityAnimNum == 2) {
                    entityAnimNum = 3;
                } else if (entityAnimNum == 3) {
                    entityAnimNum = 4;
                } else if (entityAnimNum == 4) {
                    entityAnimNum = 1;
                }
                entityAnimCounter = 0;
            }
            //Change default sprite based on the direction

        } else {
            if (entityAnimCounter < entityAnimMaxCount + 1) {
                entityAnimCounter = 0;
                entityAnimNum = 1;
                if (entityAnimNum == 1) {
                    entityAnimNum = 2;
                } else if (entityAnimNum == 2) {
                    entityAnimNum = 3;
                } else if (entityAnimNum == 3) {
                    entityAnimNum = 4;
                }
            }
        }
        //Change this however you'd like but to keep it easy I placed my logic like so
        if (entityDirection.equals("down")) {
            if (entityAnimNum == 1 || entityAnimNum == 3) {
                defaultEntityImg = entitySprites[0];
            }
            if (entityAnimNum == 2) {
                defaultEntityImg = entitySprites[1];
            }
            if (entityAnimNum == 4) {
                defaultEntityImg = entitySprites[2];
            }
        }
        if (entityDirection.equals("up")) {
            if (entityAnimNum == 1 || entityAnimNum == 3) {
                defaultEntityImg = entitySprites[3];
            }
            if (entityAnimNum == 2) {
                defaultEntityImg = entitySprites[4];
            }
            if (entityAnimNum == 4) {
                defaultEntityImg = entitySprites[5];
            }
        }
        if (entityDirection.equals("right")) {
            if (entityAnimNum == 1 || entityAnimNum == 3) {
                defaultEntityImg = entitySprites[9];
            }
            if (entityAnimNum == 2) {
                defaultEntityImg = entitySprites[10];
            }
            if (entityAnimNum == 4) {
                defaultEntityImg = entitySprites[11];
            }
        }
        if (entityDirection.equals("left")) {
            if (entityAnimNum == 1 || entityAnimNum == 3) {
                defaultEntityImg = entitySprites[6];
            }
            if (entityAnimNum == 2) {
                defaultEntityImg = entitySprites[7];
            }
            if (entityAnimNum == 4) {
                defaultEntityImg = entitySprites[8];
            }
        }
        if (entityDirection.equals("buttonreleased")) {
            if (entityDefaultDirection.equals("up")) {
                defaultEntityImg = entitySprites[3];
            }
            if (entityDefaultDirection.equals("down")) {
                defaultEntityImg = entitySprites[0];
            }
            if (entityDefaultDirection.equals("right")) {
                defaultEntityImg = entitySprites[9];
            }
            if (entityDefaultDirection.equals("left")) {
                defaultEntityImg = entitySprites[6];
            }
        }
    }

    public void initializeSpriteSheet(){
        Bitmap spritesheet1;
        int currentColumn = 0;
        int currentRow = 0;
        int numberOftiles = 0;
        BitmapFactory.Options bitmapOptions = new BitmapFactory.Options();
        bitmapOptions.inScaled = false;
        spritesheet1 = BitmapFactory.decodeResource(gameView.getResources(), R.drawable.spritesheet_red,
                bitmapOptions);
        int maxColumns = spritesheet1.getWidth()/16;
        int maxRows = spritesheet1.getHeight()/16;

        while (currentRow<maxRows){
            //Each sprite tile is given an ID based on the number of images loaded from the spritesheet
            entitySprites[numberOftiles] = Bitmap.createScaledBitmap(Bitmap.createBitmap(spritesheet1,
                            currentColumn * 16,
                            currentRow * 16,
                            16,
                            16),entityWidth,entityHeight,false);

            currentColumn ++;
            if (currentColumn == maxColumns){
                currentColumn = 0;
                currentRow ++;
            }
            numberOftiles ++;
        }
    }
}
