package droidlymobile.ca.thelegendadventure.utils;

import droidlymobile.ca.thelegendadventure.Entities.EntityInfo;
import droidlymobile.ca.thelegendadventure.GameView;
public class CollisionChecker extends EntityInfo {

    public CollisionChecker(GameView gameView){
        this.gameView = gameView;
    }

    public void checkTestCollision(EntityInfo entity,String direction){
        if (direction.equals("left")) {
            if (!(entity.screenPosX - entity.speed > 0)) {
                entity.collision = true;
                entity.screenPosX = 0;
            }
        }
        if (direction.equals("right")) {
            if (!(entity.screenPosX + entity.entityWidth + entity.speed < gameView.getDisplayWidth())) {
                entity.collision = true;
                entity.screenPosX = gameView.getDisplayWidth() - entity.entityWidth;
            }
        }
        if (direction.equals("up")) {
            if (!(entity.screenPosY - entity.speed > 0)) {
                entity.collision = true;
                entity.screenPosY = 0;
            }
        }
        if (direction.equals("down")) {
            if (!(entity.screenPosY + entity.entityHeight + entity.speed < gameView.getDisplayHeight())) {
                entity.collision = true;
                entity.screenPosY = gameView.getDisplayHeight() - entity.entityHeight;
            }
        }
    }
}
