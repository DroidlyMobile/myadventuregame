package droidlymobile.ca.thelegendadventure;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Build;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.RelativeLayout;

public class MainActivity extends AppCompatActivity {

    GameView gameView;
    RelativeLayout gamelayout;
    ImageView buttonRight,buttonLeft,buttonUp,buttonDown;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        gameView = new GameView(this);
        setContentView(R.layout.button_ui_layout);
        gamelayout = findViewById(R.id.gamelayout);
        buttonRight = findViewById(R.id.buttonright);
        buttonLeft = findViewById(R.id.buttonleft);
        buttonUp = findViewById(R.id.buttonup);
        buttonDown = findViewById(R.id.buttondown);
        gamelayout.addView(gameView);
        fullscreen();
        ontouchEvents();
        setupUI();
    }

    public void setupUI(){

    }


    @SuppressLint("ClickableViewAccessibility")
    private void ontouchEvents() {
        buttonRight.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()){
                    case MotionEvent.ACTION_DOWN:
                        gameView.checkbuttonpressed = true;
                        gameView.player.entityDirection = "right";
                        gameView.player.entityDefaultDirection = "right";
                        break;
                    case MotionEvent.ACTION_UP:
                        gameView.checkbuttonpressed = false;
                        break;
                }
                return true;
            }
        });
        buttonLeft.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()){
                    case MotionEvent.ACTION_DOWN:
                        gameView.checkbuttonpressed = true;
                        gameView.player.entityDirection = "left";
                        gameView.player.entityDefaultDirection = "left";
                        break;
                    case MotionEvent.ACTION_UP:
                        gameView.checkbuttonpressed = false;
                        break;
                }
                return true;
            }
        });
        buttonUp.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()){
                    case MotionEvent.ACTION_DOWN:
                        gameView.checkbuttonpressed = true;
                        gameView.player.entityDirection = "up";
                        gameView.player.entityDefaultDirection = "up";
                        break;
                    case MotionEvent.ACTION_UP:
                        gameView.checkbuttonpressed = false;
                       break;
                }
                return true;
            }
        });
        buttonDown.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()){
                    case MotionEvent.ACTION_DOWN:
                        gameView.checkbuttonpressed = true;
                        gameView.player.entityDirection = "down";
                        gameView.player.entityDefaultDirection = "down";
                        break;
                    case MotionEvent.ACTION_UP:
                        gameView.checkbuttonpressed = false;
                        break;

                }
                return true;
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        gameView.gameLoop.stopLoop();
    }
    public void fullscreen(){
        View decorView = this.getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | Window.FEATURE_NO_TITLE|View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);
        decorView.setSystemUiVisibility(uiOptions);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            getWindow().getAttributes().layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
    }
}