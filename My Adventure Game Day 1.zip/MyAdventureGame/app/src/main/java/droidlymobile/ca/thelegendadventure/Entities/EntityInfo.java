package droidlymobile.ca.thelegendadventure.Entities;

import android.graphics.Bitmap;
import android.graphics.Paint;
import android.graphics.RectF;

import droidlymobile.ca.thelegendadventure.GameView;

public class EntityInfo {
    public GameView gameView;
    public int posX,posY,screenPosX,screenPosY,x,y = 0;
    public int entityWidth,entityHeight = 0;
    public int entityHP,entityMaxHP = 0;
    public int speed = 0;
    public int entityAnimNum = 1;
    public int entityAnimCounter = 0;
    public int entityAnimMaxCount = 0;
    public String entityDirection,entityDefaultDirection = "";
    public RectF rectF = new RectF();
    public Paint hitboxpaint = new Paint();
    public Bitmap defaultEntityImg = null;
    public Bitmap[] entitySprites = new Bitmap[100];
    public boolean collision = false;


}
