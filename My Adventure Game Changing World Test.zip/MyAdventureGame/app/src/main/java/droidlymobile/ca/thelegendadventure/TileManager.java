package droidlymobile.ca.thelegendadventure;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class TileManager extends TileInfo{

    public TileInfo[] tileInfo = new TileInfo[100];

    public TileManager(GameView gameView){
        this.gameView = gameView;
        loadTilesheet();
        worldTileNum = new int[gameView.maxColumns][gameView.maxRows];
        loadMap("map1");
    }
    public void draw(Canvas canvas){
        int tileCol = 0;
        int tileRow = 0;
        while (tileCol < gameView.maxColumns && tileRow < gameView.maxRows){
            tileNum = worldTileNum[tileCol][tileRow];//Gets the tileNum at the XY position from the txt data
            int tilePosX = tileCol * gameView.defaultTilesize;//Sets the tile at the position X in the world times the scaled tilesize 160 in example
            int tilePosY = tileRow * gameView.defaultTilesize;//Sets position Y times scaled tilesize
            int tileScreenX = tilePosX - gameView.player.posX + gameView.player.screenPosX;
            int tileScreenY = tilePosY - gameView.player.posY + gameView.player.screenPosY;

            if(tileScreenX > -gameView.defaultTilesize
                    && tileScreenY > -gameView.defaultTilesize
                    && tileScreenX < gameView.getDisplayWidth() + (gameView.defaultTilesize *2)
                    && tileScreenY < (gameView.getDisplayHeight() + gameView.defaultTilesize )){

                if (tileInfo[tileNum].defaultTileimg != null) {
                    canvas.drawBitmap(tileInfo[tileNum].defaultTileimg, tileScreenX, tileScreenY, null);
                }
            }
            tileCol ++;
            if (tileCol == gameView.maxColumns){//Check if tileCol reaches the end in this case 100 tiles then resets back to 0 then increases rows
                tileCol = 0;
                tileRow++;
            }
        }

    }
    public void loadMap(final String _mapname){//Used to load map from the raw folder in res
        try {
            inputStream = gameView.getContext().getResources().openRawResource(
                    gameView.getContext().getResources().getIdentifier(
                            _mapname,"raw", gameView.getContext().getPackageName()));
            bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            int column = 0;
            int row = 0;
            while (column< gameView.maxColumns && row < gameView.maxRows){
                String line = bufferedReader.readLine();
                while (column < gameView.maxColumns){
                    //Splits the line to read the data from the text
                    String[] numbers = line.split(" ");
                    int num = Integer.parseInt(numbers[column]);
                    worldTileNum[column][row]= num;
                    column ++;
                }
                if (column == gameView.maxColumns){
                    column = 0;
                    row ++;
                }
            }
            bufferedReader.close();
        }catch (Exception e){

        }
    }

    public void loadTilesheet(){
        Bitmap tilesheet;
        int col1 = 0;
        int row1 = 0;
        int numoftiles = 0;
        BitmapFactory.Options bitmapOptions = new BitmapFactory.Options();
        bitmapOptions.inScaled = false;
        tilesheet = BitmapFactory.decodeResource(gameView.getResources(),
                R.drawable.bottom_layer1_tilesheet,bitmapOptions);
        int maxcol1 = tilesheet.getWidth()/16;
        int maxrow1 = tilesheet.getHeight()/16;
        while (row1 < maxrow1){
            tileImgs[numoftiles] = Bitmap.createScaledBitmap(Bitmap.createBitmap
                    (tilesheet,col1 * 16,row1 * 16,16,16),gameView.defaultTilesize,
                    gameView.defaultTilesize,false);
            col1 ++;
            if (col1 == maxcol1){
                col1 = 0;
                row1 ++;
            }
            numoftiles ++;
            tilesList.add(numoftiles);
        }
        setUpTileInfo();//After tiles are loaded from tilesheet all tile details are setup
    }
    public void setUpTileInfo() {//This is used to check tiles that are collidable then sets the tile to be collidable
        collisionTiles.add(String.valueOf(0));
        collisionTiles.add(String.valueOf(1));
        collisionTiles.add(String.valueOf(2));
        collisionTiles.add(String.valueOf(3));
        collisionTiles.add(String.valueOf(9));
        collisionTiles.add(String.valueOf(7));
        for (int tileID = 0; tileID < tilesList.size(); tileID++) {
            tileInfo[tileID] = new TileInfo();
            tileInfo[tileID].defaultTileimg = tileImgs[tileID];
            if (collisionTiles.contains(String.valueOf((int) tileID))) {
                tileInfo[tileID].tileCollision = true;
            }
        }
        animatedTileList.add(String.valueOf(9));
        animatedTileList.add(String.valueOf(6));
    }

    public void drawAllAnimatedTiles(Canvas canvas){
        Bitmap animatedTilewater = null;
        Bitmap animatedTileflowers = null;
        tileAnimCount ++;
        System.out.println(tileAnimCount);
        if(tileAnimCount > 32){

            if(tileAnimNum == 1){
                tileAnimNum = 2;
            }else
            if(tileAnimNum == 2){
                tileAnimNum = 3;
            }else
            if(tileAnimNum == 3){
                tileAnimNum = 4;
            }else
            if(tileAnimNum == 4){
                tileAnimNum = 1;
            }
            tileAnimCount = 0;
        }

        if (tileAnimNum == 1) {
            animatedTilewater = tileInfo[9].defaultTileimg;
            animatedTileflowers = tileInfo[6].defaultTileimg;
        }
        if (tileAnimNum == 2) {
            animatedTilewater = tileInfo[10].defaultTileimg;
            animatedTileflowers = tileInfo[5].defaultTileimg;
        }
        if (tileAnimNum == 3) {
            animatedTilewater = tileInfo[11].defaultTileimg;
            animatedTileflowers = tileInfo[6].defaultTileimg;
        }
        if (tileAnimNum == 4) {
            animatedTilewater = tileInfo[9].defaultTileimg;
            animatedTileflowers = tileInfo[5].defaultTileimg;
        }
        int tileCol = 0;
        int tileRow = 0;
        while (tileCol < gameView.maxColumns && tileRow < gameView.maxRows){
            tileNum2 = worldTileNum[tileCol][tileRow];//Gets the tileNum at the XY position from the txt data
            int tilePosX = tileCol * gameView.defaultTilesize;//Sets the tile at the position X in the world times the scaled tilesize 160 in example
            int tilePosY = tileRow * gameView.defaultTilesize;//Sets position Y times scaled tilesize
            int tileScreenX = tilePosX - gameView.player.posX + gameView.player.screenPosX;
            int tileScreenY = tilePosY - gameView.player.posY + gameView.player.screenPosY;

            if(tileScreenX > -gameView.defaultTilesize
                    && tileScreenY > -gameView.defaultTilesize
                    && tileScreenX < gameView.getDisplayWidth() + (gameView.defaultTilesize *2)
                    && tileScreenY < (gameView.getDisplayHeight() + gameView.defaultTilesize )){

                if (tileNum2 == 9){
                    if (animatedTilewater != null) {
                        canvas.drawBitmap(animatedTilewater, tileScreenX, tileScreenY, null);
                    }
                }
                if (tileNum2 == 6){
                    if (animatedTileflowers != null) {
                        canvas.drawBitmap(animatedTileflowers, tileScreenX, tileScreenY, null);
                    }
                }
            }
            tileCol ++;
            if (tileCol == gameView.maxColumns){//Check if tileCol reaches the end in this case 100 tiles then resets back to 0 then increases rows
                tileCol = 0;
                tileRow++;
            }
        }
    }
}
