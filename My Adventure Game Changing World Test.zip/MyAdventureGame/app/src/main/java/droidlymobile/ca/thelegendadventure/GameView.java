package droidlymobile.ca.thelegendadventure;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import androidx.annotation.NonNull;

import droidlymobile.ca.thelegendadventure.Entities.Player;
import droidlymobile.ca.thelegendadventure.utils.CollisionChecker;
import droidlymobile.ca.thelegendadventure.utils.ControllerButtons;
import droidlymobile.ca.thelegendadventure.utils.DpadButtons;
import droidlymobile.ca.thelegendadventure.utils.Joystick;

public class GameView extends SurfaceView implements SurfaceHolder.Callback {

    SurfaceHolder surfaceHolder;
    public GameLoop2 gameLoop;
    public Paint textpaint = new Paint();
    public boolean buttontouched = false;
    public Player player;
    public boolean checkbuttonpressed = false;
    public boolean buttonright,buttonleft,buttonup,buttondown,buttonattack = false;
    public CollisionChecker collisionChecker;
    public int maxColumns,maxRows,defaultTilesize;
    public TileManager tileManager;
    public String checkbutton = "none";
    public String checkbutton2 = "none";
    public int pointerid,pointerindex = 0;
    public double actuator = 0;
    public boolean leftbutton = false;
    public boolean abutton = false;
    public Joystick joystick,joystick2;
    public int joystickPointerId,joystickPointerId2 = 0;
    public int dpadpointerid,buttonapointerid = 0;
    public ControllerButtons buttonLeft,buttonRight,buttonDown,buttonUp,buttonA;
    public int buttonWidth,buttonHeight = 0;
    public int fingerX,fingerY =0;

    public GameView(Context context){
        super(context);
        surfaceHolder = getHolder();
        surfaceHolder.addCallback(this);
        gameLoop = new GameLoop2(this,surfaceHolder);
        textpaint.setColor(Color.WHITE);
        textpaint.setTextSize(50);
        defaultTilesize = 160;
        player = new Player(this);
        collisionChecker = new CollisionChecker(this);
        maxColumns = 25;
        maxRows = 25;
        tileManager = new TileManager(this);
        buttonWidth = getDisplayHeight()/6;
        buttonHeight = getDisplayHeight()/6;
        buttonLeft = new ControllerButtons(this,0,buttonHeight*4);
        buttonRight = new ControllerButtons(this,buttonWidth*2,buttonHeight*4);
        buttonDown = new ControllerButtons(this,buttonWidth,buttonHeight*5);
        buttonUp = new ControllerButtons(this,buttonWidth,buttonHeight*3);

        buttonA = new ControllerButtons(this,getDisplayWidth() - buttonWidth,buttonHeight*4);
    }

    public void update(){
        player.update();
    }
    public void draw(Canvas canvas){
        super.draw(canvas);
        tileManager.draw(canvas);
        tileManager.drawAllAnimatedTiles(canvas);
        canvas.drawText(String.valueOf(gameLoop.getAverageFPS()),
                getDisplayWidth()-320,
                textpaint.getTextSize() * 2, textpaint);

        canvas.drawText("CHECK TILE " + String.valueOf(collisionChecker.checkTile1) + " "
                        + " PLAYER DIRECTION "
                        + player.entityDirection,
                getDisplayWidth()-1000,
                textpaint.getTextSize() * 3, textpaint);
        player.draw(canvas);
        buttonLeft.draw(canvas);
        buttonRight.draw(canvas);
        buttonDown.draw(canvas);
        buttonUp.draw(canvas);
        buttonA.draw(canvas);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        //Touch appears to function now as of May 31st with movement and attacking hopefully
        int pointIndex = event.getActionIndex();
        int pointID = event.getPointerId(pointIndex);
        switch (event.getActionMasked()){
            case 0:
            case 5:
                if (buttonA.getXY((int) event.getX(event.getActionIndex()), (int) event.getY(event.getActionIndex()))){
                    if (!player.entityAttacking) {
                        checkbuttonpressed = true;
                        player.entityAttacking = true;
                        player.entityDown = false;
                        player.entityUp = false;
                        player.entityRight = false;
                        player.entityLeft = false;
                        player.entityAnimCounter = 0;
                        player.entityAnimNum = 1;
                    }
                }
            case 2: //check finger move
                dpadpointerid = event.getPointerCount();
                if (!player.entityDirection.equals("attack")) {
                    if (buttonLeft.getXY((int) event.getX(event.getActionIndex()), (int) event.getY(event.getActionIndex()))) {
                        if (!player.entityRight && !player.entityDown && !player.entityUp) {
                            checkbuttonpressed = true;
                            player.entityLeft = true;
                            checkbutton = "left";
                        }
                    } else if (buttonRight.getXY((int) event.getX(event.getActionIndex()), (int) event.getY(event.getActionIndex()))) {
                        if (!player.entityLeft && !player.entityDown && !player.entityUp) {
                            checkbuttonpressed = true;
                            player.entityRight = true;
                            checkbutton = "right";
                        }
                    } else if (buttonDown.getXY((int) event.getX(event.getActionIndex()), (int) event.getY(event.getActionIndex()))) {
                        if (!player.entityLeft && !player.entityRight && !player.entityUp) {
                            checkbuttonpressed = true;
                            player.entityDown = true;
                            checkbutton = "down";
                        }
                    } else if (buttonUp.getXY((int) event.getX(event.getActionIndex()), (int) event.getY(event.getActionIndex()))) {
                        if (!player.entityLeft && !player.entityRight && !player.entityDown) {
                            checkbuttonpressed = true;
                            player.entityUp = true;
                            checkbutton = "up";
                        }
                    } else {
                        /*if (!(buttonA.getXY((int) event.getX(event.getActionIndex()),
                                (int) event.getY(event.getActionIndex())))
                                && event.getPointerCount() == 1) {*/
                        if (!(buttonA.getXY((int) event.getX(event.getActionIndex()),
                                (int) event.getY(event.getActionIndex())))) {
                            checkbuttonpressed = false;
                            player.entityLeft = false;
                            player.entityRight = false;
                            player.entityDown = false;
                            player.entityUp = false;
                            checkbutton = "none";
                        }
                    }
                }
                return true;

            case 1:
            case 6:
                if (!player.entityDirection.equals("attack")) {
                    if (buttonLeft.getXY((int) event.getX(event.getActionIndex()), (int) event.getY(event.getActionIndex()))) {
                        if (!player.entityRight && !player.entityDown && !player.entityUp) {
                            checkbuttonpressed = false;
                            player.entityLeft = false;
                            checkbutton = "none";
                        }
                    } else if (buttonRight.getXY((int) event.getX(event.getActionIndex()), (int) event.getY(event.getActionIndex()))) {
                        if (!player.entityLeft && !player.entityDown && !player.entityUp) {
                            checkbuttonpressed = false;
                            player.entityRight = false;
                            checkbutton = "none";
                        }
                    } else if (buttonDown.getXY((int) event.getX(event.getActionIndex()), (int) event.getY(event.getActionIndex()))) {
                        if (!player.entityLeft && !player.entityRight && !player.entityUp) {
                            checkbuttonpressed = false;
                            player.entityDown = false;
                            checkbutton = "none";
                        }
                    }else if (buttonUp.getXY((int) event.getX(event.getActionIndex()), (int) event.getY(event.getActionIndex()))) {
                        if (!player.entityLeft && !player.entityRight && !player.entityDown) {
                            checkbuttonpressed = false;
                            player.entityUp = false;
                            checkbutton = "none";
                        }
                    }
                }

                return true;
        }
        return super.onTouchEvent(event);
    }

    @Override
    public void surfaceCreated(@NonNull SurfaceHolder holder) {
        if (gameLoop.getState().equals(Thread.State.TERMINATED)){
            surfaceHolder = getHolder();
            surfaceHolder.addCallback(this);
            gameLoop = new GameLoop2(this,surfaceHolder);
        }
        gameLoop.startLoop();
    }

    @Override
    public void surfaceChanged(@NonNull SurfaceHolder holder, int format, int width, int height) {

    }

    @Override
    public void surfaceDestroyed(@NonNull SurfaceHolder holder) {

    }

    public int getDisplayWidth(){
        return getContext().getResources().getDisplayMetrics().widthPixels;
    }
    public int getDisplayHeight(){
        return getContext().getResources().getDisplayMetrics().heightPixels;
    }
}
