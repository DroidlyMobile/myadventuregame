package droidlymobile.ca.thelegendadventure.Entities;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;

import droidlymobile.ca.thelegendadventure.GameView;
import droidlymobile.ca.thelegendadventure.R;
import droidlymobile.ca.thelegendadventure.utils.TrimBitmap;

public class Player extends EntityInfo{

    public Player(GameView gameView){
        this.gameView = gameView;
        initialize();
    }
    public void initialize(){
        entityWidth = gameView.defaultTilesize;
        entityHeight = gameView.defaultTilesize;
        hitboxpaint.setColor(Color.GREEN);
        screenPosX = gameView.getDisplayWidth()/2 - entityWidth/2;
        screenPosY = gameView.getDisplayHeight()/2 - entityHeight/2;
        initializeSpriteSheet();
        dummyImg = new TrimBitmap().trim(entitySprites[0]);
        rectF.left = (entitySprites[0].getWidth()-dummyImg.getWidth())/2;
        rectF.right = dummyImg.getWidth();
        rectF.top = 40;
        rectF.bottom = dummyImg.getHeight()-40;
        defaultEntityImg = entitySprites[0];
        entityAnimMaxCount = 12;
        speed = 10;
        posX = gameView.defaultTilesize * 3;
        posY = gameView.defaultTilesize * 3;
    }
    public void update(){
        updateEntityAnimations();
        updateEntityPosXY();
    }
    public void draw(Canvas canvas){
        canvas.drawRect(screenPosX + rectF.left,screenPosY + rectF.top,
                screenPosX + rectF.left + rectF.right,
                screenPosY + rectF.top + rectF.bottom,
                hitboxpaint);
        canvas.drawBitmap(defaultEntityImg,screenPosX,screenPosY,null);
    }

    private void updateEntityPosXY() {
        collision = false;
        gameView.collisionChecker.checkTileCollision(this,entityDirection);
            switch (entityDirection) {
                case "right":
                    if (!collision) {
                        posX += speed;
                    }
                    break;
                case "left":
                    if (!collision) {
                        posX -= speed;
                    }
                    break;
                case "down":
                    if (!collision) {
                        posY += speed;
                    }
                    break;
                case "up":
                    if (!collision) {
                        posY -= speed;
                    }
                    break;
        }
    }

    public void updateEntityAnimations() {
        if (gameView.checkbuttonpressed == false){
            entityDirection = "buttonreleased";
        }
        if (gameView.checkbuttonpressed) {
            entityAnimCounter++;
            if (entityAnimCounter > entityAnimMaxCount) {
                if (entityAnimNum == 1) {
                    entityAnimNum = 2;
                } else if (entityAnimNum == 2) {
                    entityAnimNum = 3;
                } else if (entityAnimNum == 3) {
                    entityAnimNum = 4;
                } else if (entityAnimNum == 4) {
                    entityAnimNum = 1;
                }
                entityAnimCounter = 0;
            }

        } else {
            if (entityAnimCounter < entityAnimMaxCount + 1) {
                entityAnimCounter = 0;
                entityAnimNum = 1;
                if (entityAnimNum == 1) {
                    entityAnimNum = 2;
                } else if (entityAnimNum == 2) {
                    entityAnimNum = 3;
                } else if (entityAnimNum == 3) {
                    entityAnimNum = 4;
                }
            }
        }

        if (entityDirection.equals("down")) {
            if (entityAnimNum == 1 || entityAnimNum == 3) {
                defaultEntityImg = entitySprites[0];
            }
            if (entityAnimNum == 2) {
                defaultEntityImg = entitySprites[1];
            }
            if (entityAnimNum == 4) {
                defaultEntityImg = entitySprites[2];
            }
        }
        if (entityDirection.equals("up")) {
            if (entityAnimNum == 1 || entityAnimNum == 3) {
                defaultEntityImg = entitySprites[3];
            }
            if (entityAnimNum == 2) {
                defaultEntityImg = entitySprites[4];
            }
            if (entityAnimNum == 4) {
                defaultEntityImg = entitySprites[5];
            }
        }
        if (entityDirection.equals("right")) {
            if (entityAnimNum == 1 || entityAnimNum == 3) {
                defaultEntityImg = entitySprites[9];
            }
            if (entityAnimNum == 2) {
                defaultEntityImg = entitySprites[10];
            }
            if (entityAnimNum == 4) {
                defaultEntityImg = entitySprites[11];
            }
        }
        if (entityDirection.equals("left")) {
            if (entityAnimNum == 1 || entityAnimNum == 3) {
                defaultEntityImg = entitySprites[6];
            }
            if (entityAnimNum == 2) {
                defaultEntityImg = entitySprites[7];
            }
            if (entityAnimNum == 4) {
                defaultEntityImg = entitySprites[8];
            }
        }
        if (entityDirection.equals("buttonreleased")) {
            if (entityDefaultDirection.equals("up")) {
                defaultEntityImg = entitySprites[3];
            }
            if (entityDefaultDirection.equals("down")) {
                defaultEntityImg = entitySprites[0];
            }
            if (entityDefaultDirection.equals("right")) {
                defaultEntityImg = entitySprites[9];
            }
            if (entityDefaultDirection.equals("left")) {
                defaultEntityImg = entitySprites[6];
            }
        }
    }

    public void initializeSpriteSheet(){
        Bitmap spritesheet1;
        int currentColumn = 0;
        int currentRow = 0;
        int numberOftiles = 0;
        BitmapFactory.Options bitmapOptions = new BitmapFactory.Options();
        bitmapOptions.inScaled = false;
        spritesheet1 = BitmapFactory.decodeResource(gameView.getResources(), R.drawable.spritesheet_red,
                bitmapOptions);
        int maxColumns = spritesheet1.getWidth()/16;
        int maxRows = spritesheet1.getHeight()/16;
        while (currentRow<maxRows){
            entitySprites[numberOftiles] = Bitmap.createScaledBitmap(Bitmap.createBitmap(spritesheet1,
                            currentColumn * 16,
                            currentRow * 16,
                            16,
                            16),entityWidth,entityHeight,false);
            currentColumn ++;
            if (currentColumn == maxColumns){
                currentColumn = 0;
                currentRow ++;
            }
            numberOftiles ++;
        }
    }
}
