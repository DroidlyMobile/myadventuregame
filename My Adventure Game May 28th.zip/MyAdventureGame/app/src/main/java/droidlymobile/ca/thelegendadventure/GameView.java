package droidlymobile.ca.thelegendadventure;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import androidx.annotation.NonNull;

import droidlymobile.ca.thelegendadventure.Entities.Player;
import droidlymobile.ca.thelegendadventure.utils.CollisionChecker;

public class GameView extends SurfaceView implements SurfaceHolder.Callback {

    SurfaceHolder surfaceHolder;
    public GameLoop2 gameLoop;
    public Paint textpaint = new Paint();
    public boolean buttontouched = false;
    public Player player;
    public boolean checkbuttonpressed = false;
    public CollisionChecker collisionChecker;
    public int maxColumns,maxRows,defaultTilesize;
    public TileManager tileManager;

    public GameView(Context context){
        super(context);
        surfaceHolder = getHolder();
        surfaceHolder.addCallback(this);
        gameLoop = new GameLoop2(this,surfaceHolder);
        textpaint.setColor(Color.BLUE);
        textpaint.setTextSize(50);
        defaultTilesize = 160;
        player = new Player(this);
        collisionChecker = new CollisionChecker(this);
        maxColumns = 25;
        maxRows = 25;
        tileManager = new TileManager(this);
    }
    public void update(){
        player.update();
    }
    public void draw(Canvas canvas){
        super.draw(canvas);
        tileManager.draw(canvas);
        tileManager.drawAllAnimatedTiles(canvas);
            canvas.drawText(String.valueOf(gameLoop.getAverageFPS()),
                    getDisplayWidth()-320,
                    textpaint.getTextSize() * 2, textpaint);
        player.draw(canvas);
    }

    @Override
    public void surfaceCreated(@NonNull SurfaceHolder holder) {
        if (gameLoop.getState().equals(Thread.State.TERMINATED)){
            surfaceHolder = getHolder();
            surfaceHolder.addCallback(this);
            gameLoop = new GameLoop2(this,surfaceHolder);
        }
        gameLoop.startLoop();
    }

    @Override
    public void surfaceChanged(@NonNull SurfaceHolder holder, int format, int width, int height) {

    }

    @Override
    public void surfaceDestroyed(@NonNull SurfaceHolder holder) {

    }

    public int getDisplayWidth(){
        return getContext().getResources().getDisplayMetrics().widthPixels;
    }
    public int getDisplayHeight(){
        return getContext().getResources().getDisplayMetrics().heightPixels;
    }
}
