package droidlymobile.ca.thelegendadventure;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.Random;

import droidlymobile.ca.thelegendadventure.Entities.Player;
import droidlymobile.ca.thelegendadventure.Objects.Objects;
import droidlymobile.ca.thelegendadventure.utils.BigGenerator;
import droidlymobile.ca.thelegendadventure.utils.CollisionChecker;
import droidlymobile.ca.thelegendadventure.utils.ControllerButtons;
import droidlymobile.ca.thelegendadventure.utils.Joystick;

public class GameView extends SurfaceView implements SurfaceHolder.Callback {
    SurfaceHolder surfaceHolder;
    public GameLoop2 gameLoop;
    public Paint textpaint = new Paint();
    public boolean buttontouched = false;
    public Player player;
    public boolean checkbuttonpressed = false;
    public boolean buttonright,buttonleft,buttonup,buttondown,buttonattack = false;
    public CollisionChecker collisionChecker;
    public int maxColumns,maxRows,defaultTilesize;
    public TileManager tileManager;
    public String checkbutton = "none";
    public String checkbutton2 = "none";
    public int pointerid,pointerindex = 0;
    public double actuator = 0;
    public boolean leftbutton = false;
    public boolean abutton = false;
    public Joystick joystick,joystick2;
    public int joystickPointerId,joystickPointerId2 = 0;
    public int dpadpointerid,buttonapointerid = 0;
    public ControllerButtons buttonLeft,buttonRight,buttonDown,buttonUp,buttonA;
    public int buttonWidth,buttonHeight = 0;
    public int fingerX,fingerY =0;
    public Paint uipaint = new Paint();
    public int poopX = - 1;
    public int poopY = 0;
    public   ArrayList<Integer> yPositions = new ArrayList<>();
    public   ArrayList<Integer> xPositions = new ArrayList<>();
    public boolean entranceloaded = false;
    public int x1 = 0;
    public int tilecheck = 0;
    public ArrayList<Integer> holes = new ArrayList<Integer>();
    public Objects[] objects;

    public GameView(Context context){
        super(context);
        surfaceHolder = getHolder();
        surfaceHolder.addCallback(this);
        gameLoop = new GameLoop2(this,surfaceHolder);
        textpaint.setColor(Color.WHITE);
        textpaint.setTextSize(50);
        uipaint.setColor(Color.BLACK);
        defaultTilesize = 192;
        player = new Player(this);
        collisionChecker = new CollisionChecker(this);
        maxColumns = 50;
        maxRows = 50;
        tileManager = new TileManager(this);
        buttonWidth = getDisplayHeight()/6;
        buttonHeight = getDisplayHeight()/6;
        buttonLeft = new ControllerButtons(this,0,buttonHeight*4);
        buttonRight = new ControllerButtons(this,buttonWidth*2,buttonHeight*4);
        buttonDown = new ControllerButtons(this,buttonWidth,buttonHeight*5);
        buttonUp = new ControllerButtons(this,buttonWidth,buttonHeight*3);

        buttonA = new ControllerButtons(this,getDisplayWidth() - buttonWidth,buttonHeight*4);
        new BigGenerator(this).startGeneration();
        objects = new Objects[100];
        //generateObjects();
        generateWorldObjects();
    }

    public void update(){
        player.update();
    }
    public void draw(Canvas canvas){
        super.draw(canvas);
        tileManager.draw(canvas);
        tileManager.drawAllAnimatedTiles(canvas);
        for (int o = 0; o < objects.length; o++){
            if (objects[o]!=null){
                objects[o].draw(canvas);
            }
        }
        canvas.drawText(String.valueOf(gameLoop.getAverageFPS()),
                getDisplayWidth()-320,
                textpaint.getTextSize() * 2, textpaint);

        canvas.drawRect(getDisplayWidth() - 1000,0,(getDisplayWidth()-1000)+ 2000,200,uipaint);
        canvas.drawText("CHECK TILE " + String.valueOf(collisionChecker.checkMineable1) + " " + String.valueOf(collisionChecker.checkMineable2)
                        + " PLAYER DIRECTION "
                        + player.y,
                getDisplayWidth()-1000,
                textpaint.getTextSize() * 3, textpaint);
        player.draw(canvas);
        buttonLeft.draw(canvas);
        buttonRight.draw(canvas);
        buttonDown.draw(canvas);
        buttonUp.draw(canvas);
        buttonA.draw(canvas);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        //Touch appears to function now as of May 31st with movement and attacking hopefully
        int pointIndex = event.getActionIndex();
        int pointID = event.getPointerId(pointIndex);
        switch (event.getActionMasked()){
            case 0:
            case 5:
                if (buttonA.getXY((int) event.getX(event.getActionIndex()), (int) event.getY(event.getActionIndex()))) {
                    if (!player.mineableItem) {
                        if (!player.entityAttacking) {//Attack function
                            checkbuttonpressed = true;
                            player.entityAttacking = true;
                            player.entityDown = false;
                            player.entityUp = false;
                            player.entityRight = false;
                            player.entityLeft = false;
                            player.entityAnimCounter = 0;
                            player.entityAnimNum = 1;
                        }
                    }else {
                        if (!checkbuttonpressed && !player.entityMining) {//Attack function
                                checkbuttonpressed = true;
                                player.entityMining = true;
                                player.entityDown = false;
                                player.entityUp = false;
                                player.entityRight = false;
                                player.entityLeft = false;
                                player.entityAnimCounter = 0;
                                player.entityAnimNum = 1;
                        }
                    }
                    //tilecheck = tileManager.worldTileNumLayer1[3][5];
                    //tileManager.worldTileNumLayer2[10][5] = 11;
                }
            case 2: //check finger move
                dpadpointerid = event.getPointerCount();
                if (!player.entityDirection.equals("attack")) {
                    if (buttonLeft.getXY((int) event.getX(event.getActionIndex()), (int) event.getY(event.getActionIndex()))) {
                        if (!player.entityRight && !player.entityDown && !player.entityUp) {
                            checkbuttonpressed = true;
                            player.entityLeft = true;
                            checkbutton = "left";
                        }
                    } else if (buttonRight.getXY((int) event.getX(event.getActionIndex()), (int) event.getY(event.getActionIndex()))) {
                        if (!player.entityLeft && !player.entityDown && !player.entityUp) {
                            checkbuttonpressed = true;
                            player.entityRight = true;
                            checkbutton = "right";
                        }
                    } else if (buttonDown.getXY((int) event.getX(event.getActionIndex()), (int) event.getY(event.getActionIndex()))) {
                        if (!player.entityLeft && !player.entityRight && !player.entityUp) {
                            checkbuttonpressed = true;
                            player.entityDown = true;
                            checkbutton = "down";
                        }
                    } else if (buttonUp.getXY((int) event.getX(event.getActionIndex()), (int) event.getY(event.getActionIndex()))) {
                        if (!player.entityLeft && !player.entityRight && !player.entityDown) {
                            checkbuttonpressed = true;
                            player.entityUp = true;
                            checkbutton = "up";
                        }
                    } else {
                        /*if (!(buttonA.getXY((int) event.getX(event.getActionIndex()),
                                (int) event.getY(event.getActionIndex())))
                                && event.getPointerCount() == 1) {*/
                        if (!(buttonA.getXY((int) event.getX(event.getActionIndex()),
                                (int) event.getY(event.getActionIndex())))) {
                            checkbuttonpressed = false;
                            player.entityLeft = false;
                            player.entityRight = false;
                            player.entityDown = false;
                            player.entityUp = false;
                            checkbutton = "none";
                            player.entityMining = false;
                        }
                    }
                }
                return true;

            case 1:
            case 6:
                if (!player.entityDirection.equals("attack") || !player.entityDirection.equals("mining")) {
                    if (buttonLeft.getXY((int) event.getX(event.getActionIndex()), (int) event.getY(event.getActionIndex()))) {
                        if (!player.entityRight && !player.entityDown && !player.entityUp) {
                            checkbuttonpressed = false;
                            player.entityLeft = false;
                            checkbutton = "none";
                        }
                    } else if (buttonRight.getXY((int) event.getX(event.getActionIndex()), (int) event.getY(event.getActionIndex()))) {
                        if (!player.entityLeft && !player.entityDown && !player.entityUp) {
                            checkbuttonpressed = false;
                            player.entityRight = false;
                            checkbutton = "none";
                        }
                    } else if (buttonDown.getXY((int) event.getX(event.getActionIndex()), (int) event.getY(event.getActionIndex()))) {
                        if (!player.entityLeft && !player.entityRight && !player.entityUp) {
                            checkbuttonpressed = false;
                            player.entityDown = false;
                            checkbutton = "none";
                        }
                    }else if (buttonUp.getXY((int) event.getX(event.getActionIndex()), (int) event.getY(event.getActionIndex()))) {
                        if (!player.entityLeft && !player.entityRight && !player.entityDown) {
                            checkbuttonpressed = false;
                            player.entityUp = false;
                            checkbutton = "none";
                        }
                    }
                }
                if (player.entityMining){
                    checkbuttonpressed = false;
                    checkbutton = "none";
                    player.entityMining = false;
                }

                return true;
        }
        return super.onTouchEvent(event);
    }
    public void generateObjects(){
        int columns = 0;
        int rows = 0;
        int numberofobjects = 0;
        while (rows < maxRows){
            if (tileManager.worldTileNumLayer1[columns][rows] == 1){
                if (columns == 0 || columns == maxColumns-1){
                    tileManager.worldTileNumLayer1[columns][rows] = 3;
                }else {
                    if (columns!=0 && rows!=3) {
                        int setObj = setLayer2Objects(getRandom(0,15));
                        if (setObj !=0){
                            if (numberofobjects < 100) {
                                objects[numberofobjects] = new Objects(this);
                                objects[numberofobjects].objPosX = defaultTilesize * columns;
                                objects[numberofobjects].objPosY = defaultTilesize * rows;
                            }
                        }
                        //tileManager.worldTileNumLayer2[columns][rows] = setLayer2Objects(getRandom(0, 15));
                    }
                }
            }
            columns++;
            numberofobjects ++;
            if (columns==maxColumns){
                rows++;
                columns=0;
            }
        }
    }
    public void generateWorldObjects(){
        int columns = 0;
        int rows = 0;
        while (rows < maxRows){
            if (tileManager.worldTileNumLayer1[columns][rows] == 1){
                if (columns == 0 || columns == maxColumns-1){
                    tileManager.worldTileNumLayer2[columns][rows] = 3;
                }else {
                    if (columns!=0 && rows!=3) {
                        tileManager.worldTileNumLayer2[columns][rows] = setLayer2Objects(getRandom(0, 15));
                    }
                }
            }
            columns++;
            if (columns==maxColumns){
                rows++;
                columns=0;
            }
        }
    }
    public int setLayer2Objects(int random){
        int tileNum = 0;

        if (random == 0 || random == 5){
            tileNum = 11;
        }else
        if (random == 1 || random == 3){
            tileNum = 16;
        }else
        if (random == 4){
            tileNum = 17;
        }else
        if (random == 2 || random == 6 || random == 7 || random == 9){
            tileNum = 0;
        }else
        if (random == 8 && holes.size() < 8){
            holes.add(6);
            tileNum = 6;
        }else
        if (random == 11){
            tileNum = 13;
        }else
        if (random == 12){
            tileNum = 13;
        }else
        if (random == 13 || random == 14){
            tileNum = 21;
        }

        else {
            tileNum = 0;
        }

        return tileNum;
    }

    /*public void generateSpelunky(){
        //Pick random x at y 0 for starting point

        if (!entranceloaded) {
            x1 = getRandom(0, 1);
            entranceloaded = true;
            //Place entrance room type this room cannot be placed below y0
            loadRoom(randomEntranceRoom(), x1*10, 0,
                    10, 10);
        }
        //Pick random direction to go after first room (entrance) is placed
        int randomDirection = getRandom(0,2);

        if (randomDirection == 0 && x1<5){//Right
            loadRoom(pickrandomroom(), (x1 + 1)*10, 0,
                    10, 10);
        }else {//Thrown if the entrance is at the end of the max rooms so that the next room can only be place left or down from the entrance
            int newdirection = getRandom(0,1);
            if (newdirection == 0){//LEFT
                loadRoom(pickrandomroom(), (x1 - 1)*10, 0,
                        10, 10);
            }else {//DOWN
                loadRoom(pickrandomroom(), x1, 10,
                        10, 10);
            }
        }
        if (randomDirection == 1 && x1 > 0){//Left
            loadRoom(pickrandomroom(), (x1 -1)*10, 0,
                    10, 10);
        }else {//Thrown if the entrance starts at top left corner so next room only has two directions to go right or down
            int newdirection = getRandom(0,1);
            if (newdirection == 0){//RIGHT
                loadRoom(pickrandomroom(), (x1 + 1)*10, 0,
                        10, 10);
            }else {//DOWN
                loadRoom(pickrandomroom(), x1, 10,
                        10, 10);
            }

        }
        if (randomDirection == 2){//Down nothing is needed if down is selcted after entrance is placed
            loadRoom(pickrandomroom(), x1*10, 1*10,
                    10, 10);
        }
    }*/

    /*private void generateRandomLevel() {
        int nextRoomX = -1;
        int nextRoomY = 0;
        int roomX = 0;
        int roomY = 0;
        //for (int i = 0; i < xPositions.size(); i++) {
        int i = 0;
        while (nextRoomY < 5) {
            nextRoomX ++;
            roomX = 10 * nextRoomX;
            roomY = 10 * nextRoomY;
            if (nextRoomX == 5){
                nextRoomX = -1;
                nextRoomY ++;
            }

            *//*loadRoom("layer1_binary", roomX, roomY,
                    10, 10);*//*
            loadRoom(randomEntranceRoom(), roomX, roomY,
                    10, 10);
        }
       // }
    }*/
    private String pickrandomroom() {
        String roomname = "";
        int roomnumber = getRandom(0,5);
        if (roomnumber == 0){
            roomname = "layer1";
        }
        if (roomnumber == 1){
            roomname = "layer2";
        }
        if (roomnumber == 2){
            roomname = "layer1";
        }
        if (roomnumber == 3){
            roomname = "layer3";
        }
        if (roomnumber == 4){
            roomname = "layer4";
        }
        if (roomnumber == 5){
            roomname = "layer5";
        }
        return roomname;
    }
    public String randomEntranceRoom(){
        String entrance = "";
        int roomnumber = getRandom(0,5);
        if (roomnumber == 0){
            entrance = "entrance1";
        }
        if (roomnumber == 1){
            entrance = "entrance2";
        }
        if (roomnumber == 2){
            entrance = "entrance1";
        }
        if (roomnumber == 3){
            entrance = "entrance1";
        }
        if (roomnumber == 4){
            entrance = "entrance2";
        }
        if (roomnumber == 5){
            entrance = "entrance3";
        }
        return entrance;
    }


    @Override
    public void surfaceCreated(@NonNull SurfaceHolder holder) {
        if (gameLoop.getState().equals(Thread.State.TERMINATED)){
            surfaceHolder = getHolder();
            surfaceHolder.addCallback(this);
            gameLoop = new GameLoop2(this,surfaceHolder);
        }
        gameLoop.startLoop();
    }

    @Override
    public void surfaceChanged(@NonNull SurfaceHolder holder, int format, int width, int height) {

    }

    @Override
    public void surfaceDestroyed(@NonNull SurfaceHolder holder) {

    }

    public int getDisplayWidth(){
        return getContext().getResources().getDisplayMetrics().widthPixels;
    }
    public int getDisplayHeight(){
        return getContext().getResources().getDisplayMetrics().heightPixels;
    }
    public int getRandom(int min, int max){
        Random random = new Random();
        return random.nextInt(max - min + 1) + min;
    }
}
