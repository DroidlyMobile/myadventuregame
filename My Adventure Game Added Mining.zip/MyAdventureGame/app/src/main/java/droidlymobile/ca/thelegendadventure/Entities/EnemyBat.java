package droidlymobile.ca.thelegendadventure.Entities;

import android.graphics.Canvas;

import droidlymobile.ca.thelegendadventure.GameView;

public class EnemyBat extends EntityInfo{

    public EnemyBat(GameView gameView){
        this.gameView = gameView;
    }

    public void update(){

    }

    public void draw(Canvas canvas){

    }
}
