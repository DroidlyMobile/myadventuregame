package droidlymobile.ca.thelegendadventure.Entities;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;

import droidlymobile.ca.thelegendadventure.GameView;
import droidlymobile.ca.thelegendadventure.Objects.Objects;
import droidlymobile.ca.thelegendadventure.R;
import droidlymobile.ca.thelegendadventure.utils.TrimBitmap;

public class Player extends EntityInfo{

    public Player(GameView gameView){
        this.gameView = gameView;
        initialize();
    }
    public void initialize(){
        entityWidth = gameView.defaultTilesize;
        entityHeight = gameView.defaultTilesize;
        hitboxpaint.setColor(Color.GREEN);
        screenPosX = gameView.getDisplayWidth()/2 - entityWidth/2;
        screenPosY = gameView.getDisplayHeight()/2 - entityHeight/2;
        initializeSpriteSheet();
        dummyImg = new TrimBitmap().trim(entitySprites[0]);

        rectF.left = (entitySprites[0].getWidth()-dummyImg.getWidth())/2;
        rectF.right = dummyImg.getWidth();
        rectF.top = (entitySprites[0].getHeight()-dummyImg.getHeight())/2;
        rectF.bottom = dummyImg.getHeight();
        defaultEntityImg = entitySprites[0];
        entityAnimMaxCount = 12;
        speed = 10;
        posX = gameView.defaultTilesize * 10;
        posY = gameView.defaultTilesize * 3;
        entityDefaultDirection = "down";
        equippedweapon = "none";
        maxminingspeed = 50;
        setupMineableItems();
    }
    public void update(){
        x = (int) ((posX + rectF.left + speed)/gameView.defaultTilesize);
        y = (int) ((posY + rectF.top + speed)/gameView.defaultTilesize);
        updatePlayerDirection();
        updateEntityPosXY();
    }
    public void draw(Canvas canvas){
        canvas.drawRect(screenPosX + rectF.left,screenPosY + rectF.top,
                screenPosX + rectF.left + rectF.right,
                screenPosY + rectF.top + rectF.bottom,
                hitboxpaint);
        canvas.drawBitmap(defaultEntityImg,
                screenPosX,screenPosY,null);
    }
    public void updatePlayerDirection(){
        if (entityRight){
            entityDirection = "right";
            entityDefaultDirection = "right";
        }else if (entityLeft){
            entityDirection = "left";
            entityDefaultDirection = "left";
        }else if (entityUp){
            entityDirection = "up";
            entityDefaultDirection = "up";
        }else if (entityDown){
            entityDirection = "down";
            entityDefaultDirection = "down";
        }else if (entityAttacking){
            entityDirection = "attack";
        }else if (entityMining){
            entityDirection = "mining";
        }else if (!gameView.checkbuttonpressed){
            entityDirection = "buttonreleased";
            entityAnimNum = 1;
            entityAnimCounter = 0;
        }
        if (entityDirection.equals("attack")){
            attackAnimation();
        }else if (entityDirection.equals("mining")){
            miningAnimation();
        }else {
            updateEntityAnimations();
        }

        ////Once the user presses the direction they are going we will update their animation accordingly
    }

    private void updateEntityPosXY() {
        collision = false;
        gameView.collisionChecker.checkTileCollision(this,entityDirection);
        //checkTilePlaceTiles(posX,posY);
        mineableItem = gameView.collisionChecker.checkTileSetType(this,entityDefaultDirection);
        checkMineableItems(mineableItem);
            switch (entityDirection) {
                case "right":
                    if (!collision) {
                        posX += speed;
                    }
                    break;
                case "left":
                    if (!collision) {
                        posX -= speed;
                    }
                    break;
                case "down":
                    if (!collision) {
                        posY += speed;
                    }
                    break;
                case "up":
                    if (!collision) {
                        posY -= speed;
                    }
                    break;
        }
    }

    private void checkMineableItems(boolean mineableItem) {
        if (mineableItem) {
            if (mineableitemslist.contains(gameView.collisionChecker.checkMineable1)
                    || mineableitemslist.contains(gameView.collisionChecker.checkMineable2) ) {
                //gameView.tileManager.worldTileNumLayer2[mineableposX][mineableposY] = 0;
                if (entityMining) {
                    miningspeed++;

                    if (miningspeed > 50) {
                        gameView.tileManager.tileInfoLayer2
                                [gameView.tileManager.worldTileNumLayer2
                                [gameView.collisionChecker.mineableposX]
                                [gameView.collisionChecker.mineableposY]].tilehealth -=1;
                        miningspeed = 0;
                    }

                    if (gameView.tileManager.tileInfoLayer2
                            [gameView.tileManager.worldTileNumLayer2[gameView.collisionChecker.mineableposX]
                            [gameView.collisionChecker.mineableposY]].tilehealth < 1) {
                        int tileNum = gameView.tileManager.worldTileNumLayer2[gameView.collisionChecker.mineableposX]
                                [gameView.collisionChecker.mineableposY];
                        checkTileDropObjects(gameView.collisionChecker.mineableposX,
                                gameView.collisionChecker.mineableposY,tileNum);

                        gameView.tileManager.tileInfoLayer2
                                [gameView.tileManager.worldTileNumLayer2
                                [gameView.collisionChecker.mineableposX]
                                [gameView.collisionChecker.mineableposY]].tilehealth = 4;


                        gameView.tileManager.worldTileNumLayer2
                                [gameView.collisionChecker.mineableposX]
                                [gameView.collisionChecker.mineableposY] = 0;

                        miningspeed = 0;

                    }
                }

            }
        }
    }

    private void checkTileDropObjects(int mineableposX, int mineableposY, int tilenum) {
        System.out.println("GET TILE NUM " + tilenum);
        if (tilenum == 16){
            for (int o = 0; o < gameView.objects.length; o++) {
                if (gameView.objects[o] == null) {
                    gameView.objects[o] = new Objects(gameView);
                    gameView.objects[o].objPosX = posX + 160;
                    gameView.objects[o].objPosY = posY;
                    break;
                }
            }
        }
    }

    private void setupMineableItems(){
        mineableitemslist.add(11);
        mineableitemslist.add(16);
    }

    private void checkTilePlaceTiles(int posX, int posY) {
        if (gameView.collisionChecker.checkTile1 == 8 || gameView.collisionChecker.checkTile2 == 8){
            gameView.tileManager.worldTileNumLayer1[x+1]
                    [y] = 6;
        }
    }

    public void updateEntityAnimations() {
        if (gameView.checkbuttonpressed == false){
            entityDirection = "buttonreleased";
        }
        if (gameView.checkbuttonpressed) {
            entityAnimCounter++;
            if (entityAnimCounter > entityAnimMaxCount) {
                if (entityAnimNum == 1) {
                    entityAnimNum = 2;
                } else if (entityAnimNum == 2) {
                    entityAnimNum = 3;
                } else if (entityAnimNum == 3) {
                    entityAnimNum = 4;
                } else if (entityAnimNum == 4) {
                    entityAnimNum = 1;
                }
                entityAnimCounter = 0;
            }

        } else {
            if (entityAnimCounter < entityAnimMaxCount + 1) {
                entityAnimCounter = 0;
                entityAnimNum = 1;
                if (entityAnimNum == 1) {
                    entityAnimNum = 2;
                } else if (entityAnimNum == 2) {
                    entityAnimNum = 3;
                } else if (entityAnimNum == 3) {
                    entityAnimNum = 4;
                }
            }
        }
            if (entityDirection.equals("down")) {
                if (entityAnimNum == 1 || entityAnimNum == 3) {
                    defaultEntityImg = entitySprites[0];
                }
                if (entityAnimNum == 2) {
                    defaultEntityImg = entitySprites[1];
                }
                if (entityAnimNum == 4) {
                    defaultEntityImg = entitySprites[2];
                }
            }
            if (entityDirection.equals("up")) {
                if (entityAnimNum == 1 || entityAnimNum == 3) {
                    defaultEntityImg = entitySprites[3];
                }
                if (entityAnimNum == 2) {
                    defaultEntityImg = entitySprites[4];
                }
                if (entityAnimNum == 4) {
                    defaultEntityImg = entitySprites[5];
                }
            }
            if (entityDirection.equals("right")) {
                if (entityAnimNum == 1 || entityAnimNum == 3) {
                    defaultEntityImg = entitySprites[9];
                }
                if (entityAnimNum == 2) {
                    defaultEntityImg = entitySprites[10];
                }
                if (entityAnimNum == 4) {
                    defaultEntityImg = entitySprites[11];
                }
            }
            if (entityDirection.equals("left")) {
                if (entityAnimNum == 1 || entityAnimNum == 3) {
                    defaultEntityImg = entitySprites[6];
                }
                if (entityAnimNum == 2) {
                    defaultEntityImg = entitySprites[7];
                }
                if (entityAnimNum == 4) {
                    defaultEntityImg = entitySprites[8];
                }
            }

        if (entityDirection.equals("buttonreleased")) {
            if (entityDefaultDirection.equals("up")) {
                defaultEntityImg = entitySprites[3];
            }
            if (entityDefaultDirection.equals("down")) {
                defaultEntityImg = entitySprites[0];
            }
            if (entityDefaultDirection.equals("right")) {
                defaultEntityImg = entitySprites[9];
            }
            if (entityDefaultDirection.equals("left")) {
                defaultEntityImg = entitySprites[6];
            }
        }
    }

    private void attackAnimation() {
        if (gameView.checkbuttonpressed){
            entityAnimCounter ++;
            if (entityAnimCounter>6){
                if (entityAnimNum == 1){
                    entityAnimNum = 2;
                }else if (entityAnimNum == 2){
                    entityAnimNum = 3;
                }else if (entityAnimNum == 3){
                    entityAnimNum = 4;
                }
                entityAnimCounter = 0;
            }
        }else if (entityAnimCounter < 6 + 1){
            entityAnimNum = 1;
            //entityAttackAnimCounter = 0;
            if (entityAnimNum == 1){
                entityAnimNum = 2;
            }else if (entityAnimNum == 2){
                entityAnimNum = 3;
            }else if (entityAnimNum == 3){
                entityAnimNum = 4;
            }
        }
        if (entityAnimNum == 1 || entityAnimNum == 2) {
            if (entityDefaultDirection.equals("right")) {
                defaultEntityImg = entitySprites[13];
            }
            if (entityDefaultDirection.equals("left")) {
                defaultEntityImg = entitySprites[14];
            }
            if (entityDefaultDirection.equals("up")) {
                defaultEntityImg = entitySprites[15];
            }
            if (entityDefaultDirection.equals("down")) {
                defaultEntityImg = entitySprites[16];
            }
        }
        if (entityAnimNum == 3) {
            if (entityDefaultDirection.equals("right")) {
                defaultEntityImg = entitySprites[9];
            }
            if (entityDefaultDirection.equals("left")) {
                defaultEntityImg = entitySprites[6];
            }
            if (entityDefaultDirection.equals("up")) {
                defaultEntityImg = entitySprites[3];
            }
            if (entityDefaultDirection.equals("down")) {
                defaultEntityImg = entitySprites[0];
            }
        }
        if (entityAnimNum == 4) {
            gameView.checkbuttonpressed = false;
            entityAttacking = false;
            //entityDirection = "none";
            //Check if dpad is still being held down then continue walking

                if (gameView.checkbutton.equals("left")) {
                    entityLeft = true;
                    gameView.checkbuttonpressed = true;
                }
                if (gameView.checkbutton.equals("right")) {
                    entityRight = true;
                    gameView.checkbuttonpressed = true;
                }
                if (gameView.checkbutton.equals("up")) {
                    entityUp = true;
                    gameView.checkbuttonpressed = true;
                }
                if (gameView.checkbutton.equals("down")) {
                    entityDown = true;
                    gameView.checkbuttonpressed = true;
                }
        }
    }
    public void miningAnimation(){
        if (gameView.checkbuttonpressed){
            entityAnimCounter ++;
            if (entityAnimCounter>6){
                if (entityAnimNum == 1){
                    entityAnimNum = 2;
                }else if (entityAnimNum == 2){
                    entityAnimNum = 3;
                }else if (entityAnimNum == 3){
                    entityAnimNum = 4;
                }else if (entityAnimNum == 4){
                    entityAnimNum = 1;
                }
                entityAnimCounter = 0;
            }
        }else if (entityAnimCounter < 6 + 1){
            entityAnimNum = 1;
            //entityAttackAnimCounter = 0;
            if (entityAnimNum == 1){
                entityAnimNum = 2;
            }else if (entityAnimNum == 2){
                entityAnimNum = 3;
            }else if (entityAnimNum == 3){
                entityAnimNum = 4;
            }
        }
        if (entityAnimNum == 1 || entityAnimNum == 2) {
            if (entityDefaultDirection.equals("right")) {
                defaultEntityImg = entitySprites[13];
            }
            if (entityDefaultDirection.equals("left")) {
                defaultEntityImg = entitySprites[14];
            }
            if (entityDefaultDirection.equals("up")) {
                defaultEntityImg = entitySprites[15];
            }
            if (entityDefaultDirection.equals("down")) {
                defaultEntityImg = entitySprites[16];
            }
        }
        if (entityAnimNum == 3) {
            if (entityDefaultDirection.equals("right")) {
                defaultEntityImg = entitySprites[9];
            }
            if (entityDefaultDirection.equals("left")) {
                defaultEntityImg = entitySprites[6];
            }
            if (entityDefaultDirection.equals("up")) {
                defaultEntityImg = entitySprites[3];
            }
            if (entityDefaultDirection.equals("down")) {
                defaultEntityImg = entitySprites[0];
            }
        }
        if (entityAnimNum == 4) {
            if (entityDefaultDirection.equals("right")) {
                defaultEntityImg = entitySprites[9];
            }
            if (entityDefaultDirection.equals("left")) {
                defaultEntityImg = entitySprites[6];
            }
            if (entityDefaultDirection.equals("up")) {
                defaultEntityImg = entitySprites[3];
            }
            if (entityDefaultDirection.equals("down")) {
                defaultEntityImg = entitySprites[0];
            }
        }
        if (entityDirection.equals("buttonreleased")) {
            if (entityDefaultDirection.equals("up")) {
                defaultEntityImg = entitySprites[3];
            }
            if (entityDefaultDirection.equals("down")) {
                defaultEntityImg = entitySprites[0];
            }
            if (entityDefaultDirection.equals("right")) {
                defaultEntityImg = entitySprites[9];
            }
            if (entityDefaultDirection.equals("left")) {
                defaultEntityImg = entitySprites[6];
            }
        }
    }
    public void initializeSpriteSheet(){
        Bitmap spritesheet1;
        int currentColumn = 0;
        int currentRow = 0;
        int numberOftiles = 0;
        BitmapFactory.Options bitmapOptions = new BitmapFactory.Options();
        bitmapOptions.inScaled = false;
        spritesheet1 = BitmapFactory.decodeResource(gameView.getResources(),
                R.drawable.player1spritesheet,
                bitmapOptions);
        int maxColumns = spritesheet1.getWidth()/16;
        int maxRows = spritesheet1.getHeight()/16;
        while (currentRow<maxRows){
            entitySprites[numberOftiles] = Bitmap.createScaledBitmap(Bitmap.createBitmap(spritesheet1,
                            currentColumn * 16,
                            currentRow * 16,
                            16,
                            16),entityWidth,
                    entityHeight,false);
            currentColumn ++;
            if (currentColumn == maxColumns){
                currentColumn = 0;
                currentRow ++;
            }
            numberOftiles ++;
        }
    }
}
