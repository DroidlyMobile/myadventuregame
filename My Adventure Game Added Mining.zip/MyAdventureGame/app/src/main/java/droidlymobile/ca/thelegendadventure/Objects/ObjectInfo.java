package droidlymobile.ca.thelegendadventure.Objects;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.RectF;

import droidlymobile.ca.thelegendadventure.GameView;
import droidlymobile.ca.thelegendadventure.R;

public class ObjectInfo {
    public GameView gameView;
    public int objScreenX,objScreenY = 0;
    public int objPosX,objPosY = 0;
    public int objWidth,objHeight = 0;
    public RectF rectF = new RectF();
    public Bitmap[] objImages = new Bitmap[500];
}
