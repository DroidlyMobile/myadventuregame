package droidlymobile.ca.thelegendadventure.Objects;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;

import droidlymobile.ca.thelegendadventure.GameView;
import droidlymobile.ca.thelegendadventure.R;

public class Objects extends ObjectInfo {

    public Objects(GameView gameView){
        this.gameView = gameView;
        initializeObject();
        loadObjectTilesheet();
    }

    private void initializeObject() {

    }
    public void update(){

    }
    public void draw(Canvas canvas){
        objScreenX = (objPosX - gameView.player.posX) + gameView.player.screenPosX;
        objScreenY = (objPosY - gameView.player.posY) + gameView.player.screenPosY;
        if (objImages[0]!=null) {
            if (objScreenX>-gameView.defaultTilesize
                    && objScreenX+objWidth < (gameView.getDisplayWidth()+ gameView.defaultTilesize)
                    && objScreenY > -gameView.defaultTilesize
                    && objScreenY + objHeight < (gameView.getDisplayHeight() + gameView.defaultTilesize)) {
                canvas.drawBitmap(objImages[5], objScreenX, objScreenY, null);
            }
        }

    }
    public void loadObjectTilesheet(){
            Bitmap tilesheet;
            int col1 = 0;
            int row1 = 0;
            int numoftiles = 0;
            BitmapFactory.Options bitmapOptions = new BitmapFactory.Options();
            bitmapOptions.inScaled = false;
            tilesheet = BitmapFactory.decodeResource(gameView.getResources(),
                    R.drawable.groundtilesheet,bitmapOptions);
            int maxcol1 = tilesheet.getWidth()/16;
            int maxrow1 = tilesheet.getHeight()/16;
            while (row1 < maxrow1){
                objImages[numoftiles] = Bitmap.createScaledBitmap(Bitmap.createBitmap
                                (tilesheet,col1 * 16,row1 * 16,16,16),gameView.defaultTilesize,
                        gameView.defaultTilesize,false);
                col1 ++;
                if (col1 == maxcol1){
                    col1 = 0;
                    row1 ++;
                }
                numoftiles ++;
            }
        }

}
