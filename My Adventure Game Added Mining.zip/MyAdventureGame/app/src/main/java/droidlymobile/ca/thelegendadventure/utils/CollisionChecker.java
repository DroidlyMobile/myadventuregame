package droidlymobile.ca.thelegendadventure.utils;

import droidlymobile.ca.thelegendadventure.Entities.EntityInfo;
import droidlymobile.ca.thelegendadventure.GameView;
public class CollisionChecker extends EntityInfo {
    public int checkPlayerLeftSide = 0;
    public int checkPlayerRightSide = 0;
    public int setPlayerLeftX;
    public int setPlayerRightX;
    public int checkPlayerTopSide;
    public int checkPlayerBottomSide;
    public int setPlayerTopY;
    public int setPlayerBottomY;
    public CollisionChecker(GameView gameView){
        this.gameView = gameView;
    }

    public void checkTileCollision(EntityInfo entity,final String entityDirection){
        //Check Right & Left
        checkPlayerLeftSide = (int) (entity.posX + entity.rectF.left);
        checkPlayerRightSide = (int) (entity.posX + entity.rectF.left + entity.rectF.right);
        setPlayerLeftX = checkPlayerLeftSide/gameView.defaultTilesize;
        setPlayerRightX = checkPlayerRightSide/gameView.defaultTilesize;
        //Check Up & Down
        checkPlayerTopSide = (int) (entity.posY + entity.rectF.top);
        checkPlayerBottomSide = (int) (entity.posY + entity.rectF.top + entity.rectF.bottom);
        setPlayerTopY = checkPlayerTopSide/gameView.defaultTilesize;
        setPlayerBottomY = checkPlayerBottomSide/gameView.defaultTilesize;//To round the current Y value we can -1 so that when the player is walking left or right they don't collide
        //When we go left or right we want to check the top tile and bottom tile position so that the player cannot walk through the tile halfway

        switch (entityDirection){
            case "left":
                setPlayerLeftX = (checkPlayerLeftSide - entity.speed)/gameView.defaultTilesize;
                setPlayerTopY = (checkPlayerTopSide+entity.speed)/gameView.defaultTilesize;
                setPlayerBottomY = (checkPlayerBottomSide-entity.speed)/gameView.defaultTilesize;
                checkTile1 = gameView.tileManager.worldTileNumLayer1[setPlayerLeftX][setPlayerTopY];
                checkTile2 = gameView.tileManager.worldTileNumLayer1[setPlayerLeftX][setPlayerBottomY];
                checkTile1Layer2 = gameView.tileManager.worldTileNumLayer2[setPlayerLeftX][setPlayerTopY];
                checkTile2Layer2 = gameView.tileManager.worldTileNumLayer2[setPlayerLeftX][setPlayerBottomY];
                if (gameView.tileManager.tileInfoLayer1[checkTile1].tileCollision
                        || gameView.tileManager.tileInfoLayer1[checkTile2].tileCollision
                        || gameView.tileManager.tileInfoLayer2[checkTile1Layer2].tileCollision
                        || gameView.tileManager.tileInfoLayer2[checkTile2Layer2].tileCollision){
                    entity.collision = true;
                }
                break;
            case "right":
                setPlayerRightX = (checkPlayerRightSide + entity.speed)/gameView.defaultTilesize;
                setPlayerBottomY = (checkPlayerBottomSide-entity.speed)/gameView.defaultTilesize;
                setPlayerTopY = (checkPlayerTopSide+entity.speed)/gameView.defaultTilesize;
                checkTile1 = gameView.tileManager.worldTileNumLayer1[setPlayerRightX][setPlayerTopY];
                checkTile2 = gameView.tileManager.worldTileNumLayer1[setPlayerRightX][setPlayerBottomY];
                checkTile1Layer2 = gameView.tileManager.worldTileNumLayer2[setPlayerRightX][setPlayerTopY];
                checkTile2Layer2 = gameView.tileManager.worldTileNumLayer2[setPlayerRightX][setPlayerBottomY];
                if (gameView.tileManager.tileInfoLayer1[checkTile1].tileCollision
                        || gameView.tileManager.tileInfoLayer1[checkTile2].tileCollision
                        || gameView.tileManager.tileInfoLayer2[checkTile1Layer2].tileCollision
                        || gameView.tileManager.tileInfoLayer2[checkTile2Layer2].tileCollision){
                    entity.collision = true;
                }
                break;
            case "up":
                setPlayerTopY = (checkPlayerTopSide - entity.speed)/gameView.defaultTilesize;
                setPlayerRightX = (checkPlayerRightSide - entity.speed)/gameView.defaultTilesize;
                setPlayerLeftX = (checkPlayerLeftSide + entity.speed)/gameView.defaultTilesize;
                checkTile1 = gameView.tileManager.worldTileNumLayer1[setPlayerLeftX][setPlayerTopY];
                checkTile2 = gameView.tileManager.worldTileNumLayer1[setPlayerRightX][setPlayerTopY];
                checkTile1Layer2 = gameView.tileManager.worldTileNumLayer2[setPlayerLeftX][setPlayerTopY];
                checkTile2Layer2 = gameView.tileManager.worldTileNumLayer2[setPlayerRightX][setPlayerTopY];
                if (gameView.tileManager.tileInfoLayer1[checkTile1].tileCollision
                        || gameView.tileManager.tileInfoLayer1[checkTile2].tileCollision
                        || gameView.tileManager.tileInfoLayer2[checkTile1Layer2].tileCollision
                        || gameView.tileManager.tileInfoLayer2[checkTile2Layer2].tileCollision){
                    entity.collision = true;
                }
                break;
            case "down":
                setPlayerBottomY = (checkPlayerBottomSide + entity.speed)/gameView.defaultTilesize;
                setPlayerRightX = (checkPlayerRightSide - entity.speed)/gameView.defaultTilesize;
                setPlayerLeftX = (checkPlayerLeftSide + entity.speed)/gameView.defaultTilesize;
                checkTile1 = gameView.tileManager.worldTileNumLayer1[setPlayerLeftX][setPlayerBottomY];
                checkTile2 = gameView.tileManager.worldTileNumLayer1[setPlayerRightX][setPlayerBottomY];
                checkTile1Layer2 = gameView.tileManager.worldTileNumLayer2[setPlayerLeftX][setPlayerBottomY];
                checkTile2Layer2 = gameView.tileManager.worldTileNumLayer2[setPlayerRightX][setPlayerBottomY];
                if (gameView.tileManager.tileInfoLayer1[checkTile1].tileCollision
                        || gameView.tileManager.tileInfoLayer1[checkTile2].tileCollision
                        || gameView.tileManager.tileInfoLayer2[checkTile1Layer2].tileCollision
                        || gameView.tileManager.tileInfoLayer2[checkTile2Layer2].tileCollision){
                    entity.collision = true;
                }
                break;
        }
    }

    public boolean checkTileSetType(EntityInfo entity, String direction){
        boolean type = false;
        //Check Right & Left
        int checkPlayerLeftSide = (int) (entity.posX + entity.rectF.left);
        int checkPlayerRightSide = (int) (entity.posX + entity.rectF.left + entity.rectF.right);
        int setPlayerLeftX = checkPlayerLeftSide/gameView.defaultTilesize;
        int setPlayerRightX = checkPlayerRightSide/gameView.defaultTilesize;
        //Check Up & Down
        int checkPlayerTopSide = (int) (entity.posY + entity.rectF.top);
        int checkPlayerBottomSide = (int) (entity.posY + entity.rectF.top + entity.rectF.bottom);
        int  setPlayerTopY = checkPlayerTopSide/gameView.defaultTilesize;
        int setPlayerBottomY = checkPlayerBottomSide/gameView.defaultTilesize;//To round the current Y value we can -1 so that when the player is walking left or right they don't collide
        //When we go left or right we want to check the top tile and bottom tile position so that the player cannot walk through the tile halfway
        switch (direction){
            case "right":
                setPlayerRightX = (checkPlayerRightSide + entity.speed)/gameView.defaultTilesize;
                setPlayerBottomY = (checkPlayerBottomSide-entity.speed)/gameView.defaultTilesize;
                setPlayerTopY = (checkPlayerTopSide+entity.speed)/gameView.defaultTilesize;
                checkMineable1 = gameView.tileManager.worldTileNumLayer2[setPlayerRightX][setPlayerTopY];
                checkMineable2 = gameView.tileManager.worldTileNumLayer2[setPlayerRightX][setPlayerBottomY];
                mineableposX = setPlayerRightX;
                mineableposY = setPlayerTopY;
                if (gameView.tileManager.tileInfoLayer2[checkMineable1].mineable
                        || gameView.tileManager.tileInfoLayer2[checkMineable2].mineable) {
                    type = true;
                }
                break;
            case "left":
                setPlayerLeftX = (checkPlayerLeftSide - entity.speed)/gameView.defaultTilesize;
                setPlayerTopY = (checkPlayerTopSide+entity.speed)/gameView.defaultTilesize;
                setPlayerBottomY = (checkPlayerBottomSide-entity.speed)/gameView.defaultTilesize;
                checkMineable1 = gameView.tileManager.worldTileNumLayer2[setPlayerLeftX][setPlayerTopY];
                checkMineable2 = gameView.tileManager.worldTileNumLayer2[setPlayerLeftX][setPlayerBottomY];
                mineableposX = setPlayerLeftX;
                mineableposY = setPlayerTopY;
                if (gameView.tileManager.tileInfoLayer2[checkMineable1].mineable
                        || gameView.tileManager.tileInfoLayer2[checkMineable2].mineable) {
                    type = true;
                }
                break;
        }
        return type;
    }
}
