package droidlymobile.ca.thelegendadventure;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import androidx.annotation.NonNull;

import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.Random;

import droidlymobile.ca.thelegendadventure.Entities.EnemyBat;
import droidlymobile.ca.thelegendadventure.Entities.EnemyBomber;
import droidlymobile.ca.thelegendadventure.Entities.EnemySetup;
import droidlymobile.ca.thelegendadventure.Entities.EntityInfo;
import droidlymobile.ca.thelegendadventure.Entities.Player;
import droidlymobile.ca.thelegendadventure.Objects.ObjectInfo;
import droidlymobile.ca.thelegendadventure.Objects.Objects;
import droidlymobile.ca.thelegendadventure.utils.BigGenerator;
import droidlymobile.ca.thelegendadventure.utils.CollisionChecker;
import droidlymobile.ca.thelegendadventure.utils.ControllerButtons;
import droidlymobile.ca.thelegendadventure.utils.Joystick;

public class GameView extends SurfaceView implements SurfaceHolder.Callback {
    SurfaceHolder surfaceHolder;
    public GameLoop2 gameLoop;
    public Paint textpaint = new Paint();
    public boolean buttontouched = false;
    public Player player;
    public boolean checkbuttonpressed = false;
    public boolean buttonright,buttonleft,buttonup,buttondown,buttonattack = false;
    public CollisionChecker collisionChecker;
    public int maxColumns,maxRows,defaultTilesize;
    public TileManager tileManager;
    public String checkbutton = "none";
    public String checkbutton2 = "none";
    public int pointerid,pointerindex = 0;
    public double actuator = 0;
    public boolean leftbutton = false;
    public boolean abutton = false;
    public Joystick joystick,joystick2;
    public int joystickPointerId,joystickPointerId2 = 0;
    public int dpadpointerid,buttonapointerid = 0;
    public ControllerButtons buttonLeft,buttonRight,buttonDown,buttonUp,buttonA;
    public int buttonWidth,buttonHeight = 0;
    public int fingerX,fingerY =0;
    public Paint uipaint = new Paint();
    public int poopX = - 1;
    public int poopY = 0;
    public   ArrayList<Integer> yPositions = new ArrayList<>();
    public   ArrayList<Integer> xPositions = new ArrayList<>();
    public boolean entranceloaded = false;
    public int x1 = 0;
    public int tilecheck = 0;
    public ArrayList<Integer> holes = new ArrayList<Integer>();
    public Objects[] objects;
    public ArrayList<ObjectInfo> objectslist = new ArrayList<>();
    public ArrayList<Integer> objectsPosX = new ArrayList<Integer>();
    public ArrayList<Integer> objectsPosY = new ArrayList<Integer>();
    public ArrayList<Integer> tileIDS = new ArrayList<Integer>();
    public ArrayList<String> buttonlist = new ArrayList<>();
    public ArrayList<String> buttonpointerlist = new ArrayList<>();
    public int pointerID = 0;
    Vibrator v;
    public EnemySetup enemySetup;
    public EnemyBomber[] bombers = new EnemyBomber[25];
    public EnemyBat[] bats = new EnemyBat[25];

    public GameView(Context context){
        super(context);
        surfaceHolder = getHolder();
        surfaceHolder.addCallback(this);
        gameLoop = new GameLoop2(this,surfaceHolder);
        textpaint.setColor(Color.WHITE);
        textpaint.setTextSize(50);
        uipaint.setColor(Color.BLACK);
        defaultTilesize = 192;
        player = new Player(this);
        collisionChecker = new CollisionChecker(this);
        maxColumns = 50;
        maxRows = 50;
        tileManager = new TileManager(this);
        buttonWidth = getDisplayHeight()/6;
        buttonHeight = getDisplayHeight()/6;
        setupButtons();
        new BigGenerator(this).startGeneration();
        objects = new Objects[2500];
        v = (Vibrator) getContext().getSystemService(Context.VIBRATOR_SERVICE);
        enemySetup = new EnemySetup(this);
        generateObjects();
        bombers[0] = new EnemyBomber(this);
        bombers[0].posX = 12 * defaultTilesize;
        bombers[0].posY = 3 * defaultTilesize;
        bats[0] = new EnemyBat(this);
        bats[0].posX = 13 * defaultTilesize;
        bats[0].posY = 3 * defaultTilesize;
    }

    public void update(){
        player.update();
        for (int b = 0; b < bombers.length; b++){
            if (bombers[b]!=null){
                bombers[b].update();
            }
        }
        for (int b = 0; b < bats.length; b++){
            if (bats[b]!=null){
                bats[b].update();
            }
        }
        for (int o = 0; o < objects.length; o++){
            if (objects[o]!=null){
                objects[o].update();
                if ((objects[o].objPosX/defaultTilesize) == 10 && (objects[o].objPosY/defaultTilesize) ==3){
                    objects[o] = null;
                }
            }
        }

    }
    public void draw(Canvas canvas){
        super.draw(canvas);
        tileManager.draw(canvas);
        tileManager.drawAllAnimatedTiles(canvas);

        for (int o = 0; o < objects.length; o++){
            if (objects[o]!=null){
                objects[o].draw(canvas);
            }
        }
        for (int b = 0; b < bombers.length; b++){
            if (bombers[b]!=null){
                bombers[b].draw(canvas);
            }
        }
        for (int b = 0; b < bats.length; b++){
            if (bats[b]!=null){
                bats[b].draw(canvas);
            }
        }
        canvas.drawText(String.valueOf(gameLoop.getAverageFPS()),
                getDisplayWidth()-320,
                textpaint.getTextSize() * 2, textpaint);

        canvas.drawRect(getDisplayWidth() - 1000,0,(getDisplayWidth()-1000)+ 2000,200,uipaint);
        canvas.drawText("CHECK TILE " + String.valueOf(new Gson().toJson(buttonlist).toString())
                        + " " + String.valueOf(player.entityMining)
                        + " PLAYER DIRECTION "
                        + player.y,
                getDisplayWidth()-1000,
                textpaint.getTextSize() * 3, textpaint);
        player.draw(canvas);
        buttonLeft.draw(canvas);
        buttonRight.draw(canvas);
        buttonDown.draw(canvas);
        buttonUp.draw(canvas);
        buttonA.draw(canvas);
    }

    //Need to fix this by using my latest method with LIB GDX June 8th


    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getActionMasked()){
            case MotionEvent.ACTION_DOWN:
                case MotionEvent.ACTION_POINTER_DOWN:
                    pointerID = event.getPointerId(event.getActionIndex());//Get pointer ID when pointer goes down
                    System.out.println("GET POINTER INFO " + pointerID);
                    //Then check what button is being pressed, store the button info into a list along with the pointer ID
                    //handle the action given to each button ex if the list contain A BUTTON then handle the A BUTTON event
                    //This allows for the user to press the DPAD while pressing the action button
                    if (buttonA.getXY((int) event.getX(pointerID),
                            (int) event.getY(pointerID))&&!buttonlist.contains("A BUTTON")){
                        buttonlist.add("A BUTTON");
                        buttonpointerlist.add(String.valueOf(pointerID));
                    }
                    if (buttonLeft.getXY((int) event.getX(pointerID),
                            (int) event.getY(pointerID))
                            &&!buttonlist.contains("LEFT BUTTON")
                            &&!buttonlist.contains("RIGHT BUTTON")
                            &&!buttonlist.contains("UP BUTTON")
                            &&!buttonlist.contains("DOWN BUTTON")) {
                        buttonlist.add("LEFT BUTTON");
                        buttonpointerlist.add(String.valueOf(pointerID));
                    }
                    if (buttonRight.getXY((int) event.getX(pointerID),
                            (int) event.getY(pointerID))
                            &&!buttonlist.contains("RIGHT BUTTON")
                            &&!buttonlist.contains("LEFT BUTTON")
                            &&!buttonlist.contains("UP BUTTON")
                            &&!buttonlist.contains("DOWN BUTTON")) {
                        buttonlist.add("RIGHT BUTTON");
                        buttonpointerlist.add(String.valueOf(pointerID));
                    }
                    if (buttonUp.getXY((int) event.getX(pointerID),
                            (int) event.getY(pointerID))
                            &&!buttonlist.contains("UP BUTTON")
                            &&!buttonlist.contains("LEFT BUTTON")
                            &&!buttonlist.contains("RIGHT BUTTON")
                            &&!buttonlist.contains("DOWN BUTTON")) {
                        buttonlist.add("UP BUTTON");
                        buttonpointerlist.add(String.valueOf(pointerID));
                    }
                    if (buttonDown.getXY((int) event.getX(pointerID),
                            (int) event.getY(pointerID))
                            &&!buttonlist.contains("UP BUTTON")
                            &&!buttonlist.contains("LEFT BUTTON")
                            &&!buttonlist.contains("RIGHT BUTTON")
                            &&!buttonlist.contains("DOWN BUTTON")) {
                        buttonlist.add("DOWN BUTTON");
                        buttonpointerlist.add(String.valueOf(pointerID));
                    }
                    handleButtonsPressed();
                    /*return true;
                    case MotionEvent.ACTION_MOVE://GOING TO MESS WITH THIS MORE IF IT BECOMES AN ISSUE
                        if (!buttonLeft.getXY((int) event.getX(pointerID),
                                (int) event.getY(pointerID))){
                            if (buttonpointerlist.contains(String.valueOf(pointerID))) {
                                buttonlist.remove(buttonpointerlist.indexOf(String.valueOf(pointerID)));
                                buttonpointerlist.remove(buttonpointerlist.indexOf(String.valueOf(pointerID)));
                            }
                        }*/
                return true;
            //When the user releases the finger at pointer location, the indexed pointer removes the pointer and the
            //button details
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
                pointerID = event.getPointerId(event.getActionIndex());
                System.out.println("GET POINTER INFO " + pointerID);
                if (buttonpointerlist.contains(String.valueOf(pointerID))) {
                    buttonlist.remove(buttonpointerlist.indexOf(String.valueOf(pointerID)));
                    buttonpointerlist.remove(buttonpointerlist.indexOf(String.valueOf(pointerID)));
                }
                handleButtonsPressed();
                //return true;

        }
        return super.onTouchEvent(event);
    }

    private void handleButtonsPressed() {
        if (buttonlist.contains("LEFT BUTTON")){
            checkbuttonpressed = true;
            player.entityLeft = true;
            checkbutton = "left";
        }else
        if (buttonlist.contains("RIGHT BUTTON")){
            checkbuttonpressed = true;
            player.entityRight = true;
            checkbutton = "right";
        }else
        if (buttonlist.contains("UP BUTTON")){
            checkbuttonpressed = true;
            player.entityUp = true;
            checkbutton = "up";
        }else
        if (buttonlist.contains("DOWN BUTTON")){
            checkbuttonpressed = true;
            player.entityDown = true;
            checkbutton = "down";
        }else {
            checkbuttonpressed = false;
            player.entityRight = false;
            player.entityLeft = false;
            player.entityUp = false;
            player.entityDown = false;
            checkbutton = "none";
        }
        if (buttonlist.contains("A BUTTON")){
            /*if (!checkbuttonpressed && !player.entityMining) {//Attack function
                checkbuttonpressed = true;
                player.entityMining = true;
                player.entityAnimCounter = 0;
                player.entityAnimNum = 1;
            }*/
            if (!player.mineableItem) {
                if (!checkbuttonpressed && !player.entityAttacking) {//Attack function
                    checkbuttonpressed = true;
                    player.entityAttacking = true;
                    player.entityDown = false;
                    player.entityUp = false;
                    player.entityRight = false;
                    player.entityLeft = false;
                    player.entityAnimCounter = 0;
                    player.entityAnimNum = 1;
                }
            }else {
                if (!checkbuttonpressed && !player.entityMining) {//Mining function
                    checkbuttonpressed = true;
                    player.entityMining = true;
                    player.entityAnimCounter = 0;
                    player.entityAnimNum = 1;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        v.vibrate(VibrationEffect.createOneShot(10,
                                VibrationEffect.DEFAULT_AMPLITUDE));
                    } else {
                        //deprecated in API 26
                        v.vibrate(500);
                    }
                }
            }

        }else {
            player.entityMining = false;
            player.entityAnimCounter = 0;
            player.entityAnimNum = 1;
        }
    }

    public void generateObjects(){
        int currentX = 0;
        int currentY = 0;
        while (currentY < maxRows){
            if (tileManager.worldTileNumLayer1[currentX][currentY] == 1){
                //get the position of the x and y positions
                    int tileID = setLayer2Objects(getRandom(0, 15));
                    objectsPosX.add(currentX);
                    objectsPosY.add(currentY);
                    tileIDS.add(tileID);
            }
            currentX++;
            if (currentX == maxColumns){
                currentX = 0;
                currentY++;
            }
        }
        for (int i = 0; i < objectsPosX.size(); i++) {
            if (tileIDS.get(i)!=0) {
                objects[i] = new Objects(this);
                objects[i].objPosX = objectsPosX.get(i) * defaultTilesize;
                objects[i].objPosY = objectsPosY.get(i) * defaultTilesize;
                objects[i].tileID = tileIDS.get(i);
                checkObjIDSetHealth(i);
            }
        }
    }

    private void checkObjIDSetHealth(int i) {
        if (tileIDS.get(i)==16){
            objects[i].objHealth = 7;
            objects[i].objMaxHealth = 7;
        }else {
            objects[i].objHealth = 4;
            objects[i].objMaxHealth = 4;
        }
    }

    public int setLayer2Objects(int random){
        int tileNum = 0;

        if (random == 0 || random == 5){
            tileNum = 11;
        }else
        if (random == 1 || random == 3){
            tileNum = 16;
        }else
        if (random == 4){
            tileNum = 17;
        }else
        if (random == 2 || random == 6 || random == 7 || random == 9){
            tileNum = 0;
        }else
        if (random == 8 && holes.size() < 8){
            holes.add(6);
            tileNum = 6;
        }else
        if (random == 11){
            tileNum = 13;
        }else
        if (random == 12){
            tileNum = 13;
        }else
        if (random == 13 || random == 14){
            tileNum = 21;
        }

        else {
            tileNum = 0;
        }

        return tileNum;
    }


    @Override
    public void surfaceCreated(@NonNull SurfaceHolder holder) {
        if (gameLoop.getState().equals(Thread.State.TERMINATED)){
            surfaceHolder = getHolder();
            surfaceHolder.addCallback(this);
            gameLoop = new GameLoop2(this,surfaceHolder);
        }
        gameLoop.startLoop();
    }

    @Override
    public void surfaceChanged(@NonNull SurfaceHolder holder, int format, int width, int height) {

    }

    @Override
    public void surfaceDestroyed(@NonNull SurfaceHolder holder) {

    }

    public int getDisplayWidth(){
        return getContext().getResources().getDisplayMetrics().widthPixels;
    }
    public int getDisplayHeight(){
        return getContext().getResources().getDisplayMetrics().heightPixels;
    }
    public int getRandom(int min, int max){
        Random random = new Random();
        return random.nextInt(max - min + 1) + min;
    }
    public void setupButtons(){
        buttonLeft = new ControllerButtons(this,0,buttonHeight*4);
        BitmapFactory.Options bitmapOptions = new BitmapFactory.Options();
        bitmapOptions.inScaled = false;
        Bitmap dummy = BitmapFactory.decodeResource(getContext().getResources(),
                R.drawable.buttonleft,
                bitmapOptions);
        Bitmap dummy2 = BitmapFactory.decodeResource(getContext().getResources(),
                R.drawable.buttonright,
                bitmapOptions);
        Bitmap dummy3 = BitmapFactory.decodeResource(getContext().getResources(),
                R.drawable.buttondown,
                bitmapOptions);
        Bitmap dummy4 = BitmapFactory.decodeResource(getContext().getResources(),
                R.drawable.buttonup,
                bitmapOptions);
        Bitmap dummy5 = BitmapFactory.decodeResource(getContext().getResources(),
                R.drawable.abutton,
                bitmapOptions);
        buttonLeft.buttonImage = Bitmap.createScaledBitmap(Bitmap.createBitmap(dummy,
                        0,
                        0,
                        16,
                        16),192,
                192,false);
        buttonRight = new ControllerButtons(this,buttonWidth*2,buttonHeight*4);
        buttonRight.buttonImage = Bitmap.createScaledBitmap(Bitmap.createBitmap(dummy2,
                        0,
                        0,
                        16,
                        16),192,
                192,false);

        buttonDown = new ControllerButtons(this,buttonWidth,buttonHeight*5);
        buttonDown.buttonImage = Bitmap.createScaledBitmap(Bitmap.createBitmap(dummy3,
                        0,
                        0,
                        16,
                        16),192,
                192,false);
        buttonUp = new ControllerButtons(this,buttonWidth,buttonHeight*3);
        buttonUp.buttonImage = Bitmap.createScaledBitmap(Bitmap.createBitmap(dummy4,
                        0,
                        0,
                        16,
                        16),192,
                192,false);
        buttonA = new ControllerButtons(this,getDisplayWidth() - buttonWidth,buttonHeight*4);
        buttonA.buttonImage = Bitmap.createScaledBitmap(Bitmap.createBitmap(dummy5,
                        0,
                        0,
                        16,
                        16),192,
                192,false);
    }
}
