package droidlymobile.ca.thelegendadventure.Objects;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;

import java.util.Collections;

import droidlymobile.ca.thelegendadventure.GameView;
import droidlymobile.ca.thelegendadventure.R;

public class Objects extends ObjectInfo {

    public Objects(GameView gameView){
        this.gameView = gameView;
        initializeObject();
    }

    private void initializeObject() {
        objWidth = gameView.defaultTilesize;
        objHeight = gameView.defaultTilesize;
        hitbox.x = 0;
        hitbox.width = objWidth;
        hitbox.y = 0;
        hitbox.height = objHeight;
        defaultLeft =  hitbox.x;
        defaultTop =   hitbox.y;
        hitboxpaint.setColor(Color.BLUE);
        textpaint.setColor(Color.WHITE);
        textpaint.setTextSize(50);
        /*objHealth = 5;
        objMaxHealth = 5;//Default for now change later per object*/
        healthBarWidth = objWidth;
        maxHealthBarWidth = healthBarWidth;

    }
    public void update(){
        checkHealthSetHealthbar();
        checkTileIDSetImage();
    }
    public void draw(Canvas canvas){
        objScreenX = (objPosX - gameView.player.posX) + gameView.player.screenPosX;
        objScreenY = (objPosY - gameView.player.posY) + gameView.player.screenPosY;
        if (objDefaultImage!=null) {
            if (objScreenX>-gameView.defaultTilesize
                    && objScreenX + hitbox.x + hitbox.width < (gameView.getDisplayWidth() + (gameView.defaultTilesize*3))
                    && objScreenY > -gameView.defaultTilesize
                    && objScreenY + objHeight < (gameView.getDisplayHeight() + gameView.defaultTilesize)) {
                //Draw Healthbar
                if (objHealth < objMaxHealth) {
                    canvas.drawRect(objScreenX + hitbox.x, objScreenY + hitbox.y, objScreenX + healthBarWidth, objScreenY + 25, hitboxpaint);
                }
                canvas.drawBitmap(objDefaultImage, objScreenX, objScreenY, null);
                canvas.drawText(String.valueOf(objHealth),objScreenX,objScreenY,textpaint);
            }
        }
    }
    public void checkTileIDSetImage(){
        objDefaultImage = gameView.tileManager.tileImgs[tileID];
    }
    public void checkHealthSetHealthbar(){

        healthBarWidth = (int)(((double)objHealth/(double)objMaxHealth) * maxHealthBarWidth);

    }
    public void loadObjectTilesheet(){
            Bitmap tilesheet;
            int col1 = 0;
            int row1 = 0;
            int numoftiles = 0;
            BitmapFactory.Options bitmapOptions = new BitmapFactory.Options();
            bitmapOptions.inScaled = false;
            tilesheet = BitmapFactory.decodeResource(gameView.getResources(),
                    R.drawable.groundtilesheet,bitmapOptions);
            int maxcol1 = tilesheet.getWidth()/16;
            int maxrow1 = tilesheet.getHeight()/16;
            while (row1 < maxrow1){
                objImages[numoftiles] = Bitmap.createScaledBitmap(Bitmap.createBitmap
                                (tilesheet,col1 * 16,row1 * 16,16,16),gameView.defaultTilesize,
                        gameView.defaultTilesize,false);
                col1 ++;
                if (col1 == maxcol1){
                    col1 = 0;
                    row1 ++;
                }
                numoftiles ++;
            }
        }

}
