package droidlymobile.ca.thelegendadventure.Entities;

import android.graphics.Canvas;

import droidlymobile.ca.thelegendadventure.GameView;

public class EnemyBat extends EntityInfo{

    public EnemyBat(GameView gameView){
        this.gameView = gameView;
        entityAnimMaxCount = 6;
    }

    public void update(){
        updateAnimation();
    }

    public void draw(Canvas canvas){
        screenPosX = posX + gameView.player.screenPosX - gameView.player.posX;
        screenPosY = posY + gameView.player.screenPosY - gameView.player.posY;
        if (defaultEntityImg!=null) {
            canvas.drawBitmap(defaultEntityImg, screenPosX, screenPosY, null);
        }
    }

    public void updateAnimation(){
        entityAnimCounter++;
        if (entityAnimCounter > entityAnimMaxCount) {
            if (entityAnimNum == 1) {
                entityAnimNum = 2;
            } else if (entityAnimNum == 2) {
                entityAnimNum = 3;
            } else if (entityAnimNum == 3) {
                entityAnimNum = 4;
            } else if (entityAnimNum == 4) {
                entityAnimNum = 5;
            }else if (entityAnimNum == 5) {
                entityAnimNum = 6;
            }else if (entityAnimNum == 6) {
                entityAnimNum = 1;
            }
            entityAnimCounter = 0;
        }
        if (entityAnimNum == 1) {
            defaultEntityImg = gameView.enemySetup.entitySprites[5];
        }
        if (entityAnimNum == 2) {
            defaultEntityImg = gameView.enemySetup.entitySprites[6];
        }
        if (entityAnimNum == 3) {
            defaultEntityImg = gameView.enemySetup.entitySprites[7];
        }
        if (entityAnimNum == 4) {
            defaultEntityImg = gameView.enemySetup.entitySprites[8];
        }
        if (entityAnimNum == 5) {
            defaultEntityImg = gameView.enemySetup.entitySprites[9];
        }
    }
}
