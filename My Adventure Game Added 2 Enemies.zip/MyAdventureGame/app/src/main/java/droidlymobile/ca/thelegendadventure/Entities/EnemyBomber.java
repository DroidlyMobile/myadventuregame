package droidlymobile.ca.thelegendadventure.Entities;

import android.graphics.Canvas;

import droidlymobile.ca.thelegendadventure.GameView;

public class EnemyBomber extends EntityInfo{

    public EnemyBomber(GameView gameView){
        this.gameView = gameView;
        entityAnimMaxCount = 10;
    }

    public void update(){
        updateAnimation();
    }

    public void draw(Canvas canvas){
        screenPosX = posX + gameView.player.screenPosX - gameView.player.posX;
        screenPosY = posY + gameView.player.screenPosY - gameView.player.posY;
        if (defaultEntityImg!=null) {
            canvas.drawBitmap(defaultEntityImg, screenPosX, screenPosY, null);
        }
    }

    public void updateAnimation(){
        entityAnimCounter++;
        if (entityAnimCounter > entityAnimMaxCount) {
            if (entityAnimNum == 1) {
                entityAnimNum = 2;
            } else if (entityAnimNum == 2) {
                entityAnimNum = 3;
            } else if (entityAnimNum == 3) {
                entityAnimNum = 4;
            } else if (entityAnimNum == 4) {
                entityAnimNum = 1;
            }
            entityAnimCounter = 0;
        }
        if (entityAnimNum == 1 || entityAnimNum == 3) {
            defaultEntityImg = gameView.enemySetup.entitySprites[0];
        }
        if (entityAnimNum == 2) {
            defaultEntityImg = gameView.enemySetup.entitySprites[1];
        }
        if (entityAnimNum == 4) {
            defaultEntityImg = gameView.enemySetup.entitySprites[2];
        }
    }
}